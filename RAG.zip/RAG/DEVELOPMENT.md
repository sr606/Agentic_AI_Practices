# RAG Pipeline Development Log

## 1. Data Analysis

### What we started with
- Directory: `RAG/data/data1/` containing 6 JSON files (production will have many more)
- Each JSON is a **product catalog entry** from Avantor/VWR scientific supplies
- Files range from ~469 to ~4115 lines each

### Data structure discovered
```
Top-level keys per product:
- name, description, summary         → Short text fields
- classifications[]                   → Deeply nested array of specs/variants
  └── features[]
      └── featureValues[]             → Actual attribute values (size, color, material)
- categories[]                        → Product hierarchy (e.g., "Gloves")
- catalogNumbers[]                    → SKU identifiers
- vendorName, vendorCatalogNumbers    → Supplier info
- variantOptions[]                    → Size/color variants
```

### Key observations
1. Each product has **multiple variants** (sizes 5.5 through 9 for gloves) stored as separate classification entries
2. The same body text/description is repeated inside EVERY variant's classification block
3. Structured attributes (material, sterile, powder-free) are buried 4 levels deep in the JSON
4. Products span categories: gloves, bottles, tubing, pumps

---

## 2. Approach Selection

### Approaches considered and rejected

| Approach | Why rejected |
|----------|-------------|
| **Naive text chunking** (split JSON into 500-token chunks) | Destroys relationships between fields. A chunk might have "5.5" with no context that it's a glove size. |
| **Pure keyword search (BM25/Elasticsearch)** | Misses semantic queries like "protective equipment for cleanroom" when no exact keyword match exists |
| **Embed raw JSON as-is** | Embedding models waste capacity on JSON syntax (`{`, `"code":`, brackets). Terrible signal-to-noise ratio. |
| **One document per variant** | Would create 8 near-duplicate documents for one glove product (one per size). Pollutes results with redundancy. |

### Chosen approach: Hybrid RAG with structured document flattening

**Core idea:** Flatten each product JSON into a single natural-language document, embed it, and combine vector similarity with metadata filtering.

**Why this wins:**
- One product = one chunk (~200-300 tokens) — well within embedding model limits
- Natural language text embeds far better than raw JSON syntax
- Metadata filters handle exact-match queries (size 7, catalog number)
- Vector similarity handles semantic queries ("cleanroom protective gear")

---

## 3. Architecture Decisions

### Tech stack

| Component | Choice | Reasoning |
|-----------|--------|-----------|
| Vector DB | ChromaDB (PersistentClient) | Zero-config, file-based persistence, good for dev/small-medium scale |
| Embedding model | `all-MiniLM-L6-v2` | Free, runs locally, documents are short so small model suffices |
| Retrieval | Hybrid (vector + metadata + catalog lookup) | Covers semantic AND exact-match use cases |
| LLM | Azure OpenAI | User's requirement |
| Distance metric | Cosine similarity | Standard for semantic similarity with sentence-transformers |

### Design: one document per product, not per variant
Variants (sizes/colors) only differ in one attribute. Indexing each separately would:
- Bloat the index 8x for no benefit
- Return 5 results that are all the same product in different sizes
- Waste embedding compute

Instead: aggregate all sizes/colors into the product-level document as "Available Sizes: 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9"

---

## 4. Implementation Phases

### Phase 1: Document processor (`document_processor.py`)

**Goal:** Convert deeply nested JSON into clean text.

**Input:**
```json
{
  "classifications": [{
    "features": [{
      "code": "AvantorClassification/1.0/14433167_Spec Table Attributes.latex",
      "featureValues": [{"value": "Latex"}],
      "groupName": "Specification",
      "name": "Latex/Latex-free"
    }]
  }]
}
```

**Output:**
```
Product: Protexis™ Latex Classic Sterile Powder-Free Gloves, Cardinal
Supplier/Vendor: Cardinal Health
Category: Gloves
Summary: Sterile Latex surgical gloves with nitrile coating...
Specifications: Latex/Latex-free: Latex | Material: Natural Latex | Disposable
Available Sizes: 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9
Catalog Numbers: 89237-220, 89237-222, ...
```

### Phase 2: Ingestion (`ingest.py`)

Straightforward: process all JSONs → embed with sentence-transformers → upsert into ChromaDB.

### Phase 3: Retriever (`retriever.py`)

Three retrieval modes:
1. **Semantic search** — vector similarity on query embedding
2. **Filtered search** — metadata WHERE clause (category) + vector similarity
3. **Catalog number lookup** — exact match on catalog number string

### Phase 4: RAG pipeline (`rag_pipeline.py`)

Orchestrator: detects query type → picks retrieval mode → formats context → sends to Azure OpenAI.

### Phase 5: Azure OpenAI integration (`llm.py`)

Minimal wrapper: takes context + query, returns generated answer. Falls back gracefully when credentials aren't set.

---

## 5. Issues Faced & Fixes

### Issue 1: Duplicate descriptions in flattened documents

**Problem:** First ingestion produced documents with the same description repeated 8-9 times:
```
Description: Sterile Latex surgical gloves with nitrile coating...
Description: Sterile Latex surgical gloves with nitrile coating...
Description: Sterile Latex surgical gloves with nitrile coating...
... (repeated for each variant)
```

**Root cause:** The same `bodyText` and `bulletPoint` features exist in every variant's classification entry. Iterating all classifications without dedup collected them N times.

**Fix:** Changed `body_texts` and `bullet_points` from `list` to `set` in `extract_classification_features()`. Same for `sizes` and `colors`. Duplicates are now eliminated at the extraction level.

---

### Issue 2: ChromaDB metadata filter with boolean values

**Problem:** Stored `"sterile": True` (Python bool) in metadata. ChromaDB's WHERE clause handling of booleans was inconsistent, causing filter failures.

**Fix:** Changed to string values: `"sterile": "yes"` / `"no"`. ChromaDB handles string equality reliably.

---

### Issue 3: Overly strict metadata filtering returning zero results

**Problem:** Query "sterile latex gloves size 7" produced 0 results because the filter combined:
```python
{"$and": [
    {"sizes": {"$contains": "7"}},      # substring match attempt
    {"material": {"$contains": "Latex"}},
    {"sterile": True},
    {"category": {"$contains": "Gloves"}}
]}
```
ChromaDB's `$contains` doesn't do substring matching on metadata strings — it's a full-value match.

**Root cause:** Sizes stored as `"5.5,6,6.5,7,7.5,8,8.5,9"` — a comma-separated string. `$contains` with value `"7"` doesn't match within this string.

**Fix (two-part):**
1. Reduced metadata filters to only high-confidence, exact-match fields (category name)
2. Added **post-retrieval filtering**: after vector search returns candidates, boost products whose `sizes` field contains the requested size to the top of results. This way size filtering enhances ranking without eliminating results.

---

### Issue 4: Catalog number lookup failure

**Problem:** `search_by_catalog_number("89237-226")` returned 0 results despite the product existing.

**Root cause:** Same `$contains` issue — ChromaDB metadata `$contains` operator does full-value equality, not substring search. Catalog numbers stored as `"89237-220,89237-234,89237-232,..."` never matched a single number.

**Fix:** Replaced the ChromaDB WHERE query with a full collection scan + Python string `in` check:
```python
def search_by_catalog_number(catalog_number: str) -> list[dict]:
    all_results = collection.get(include=["documents", "metadatas"])
    for i, meta in enumerate(all_results["metadatas"]):
        if catalog_number in meta.get("catalog_numbers", ""):
            # match found
```

**Tradeoff:** This is O(n) over all products. Acceptable for <100k products. For larger scale, would need a separate inverted index or store each catalog number as a separate ChromaDB entry with a foreign key.

---

### Issue 5: Environment setup challenges

**Problem:** System Python on Debian had no pip (`ensurepip` disabled for system python).

**Fix:** Created a virtual environment (`python3 -m venv .venv`) which has its own pip, then installed all dependencies there.

---

## 6. Final Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    User Query                             │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              Query Analysis (rag_pipeline.py)             │
│  • Detect catalog number pattern (xxxxx-xxx)             │
│  • Extract category keywords for metadata filter         │
│  • Extract size for post-retrieval boosting              │
└─────────────────────┬───────────────────────────────────┘
                      │
          ┌───────────┴───────────┐
          ▼                       ▼
┌──────────────────┐   ┌──────────────────────┐
│ Catalog # Lookup │   │   Vector Search       │
│ (exact match)    │   │ + Metadata Filter     │
│                  │   │ + Post-filter boost   │
└────────┬─────────┘   └──────────┬───────────┘
         │                        │
         └────────────┬───────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              Format Context (top-K results)               │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│           Azure OpenAI (llm.py)                          │
│  • System prompt: product search assistant                │
│  • Temperature: 0.3 (factual, low creativity)            │
│  • Returns natural language answer                       │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│                  User Answer                              │
└─────────────────────────────────────────────────────────┘
```

---

## 7. File Structure

```
RAG/
├── .env.example          # Template for Azure OpenAI credentials
├── .venv/                # Python virtual environment
├── config.py             # All configuration (paths, model names, Azure settings)
├── document_processor.py # JSON → natural language flattening + metadata extraction
├── ingest.py             # Embedding + ChromaDB storage
├── retriever.py          # Hybrid search engine
├── rag_pipeline.py       # Orchestrator: retrieve → format → generate
├── llm.py                # Azure OpenAI client wrapper
├── main.py               # CLI entry point (ingest / search / interactive)
├── requirements.txt      # Dependencies
├── data/
│   └── data1/            # Source product JSONs
│       ├── 10012340.json
│       ├── 10012344.json
│       └── ...
└── vector_store/         # ChromaDB persisted embeddings (auto-generated)
```

---

## 8. Usage

```bash
cd RAG
source .venv/bin/activate

# Step 1: Ingest product data
python main.py ingest

# Step 2: Configure Azure OpenAI
cp .env.example .env
# Edit .env with your credentials

# Step 3: Query
python main.py search "sterile latex gloves size 7"
python main.py search "89237-226"
python main.py interactive
```

---

## 9. Production Considerations

### What would change at scale (10k+ products):

| Concern | Current | Production |
|---------|---------|------------|
| Vector DB | ChromaDB local | Qdrant/Pinecone/Weaviate (managed, horizontal scaling) |
| Catalog lookup | Full scan O(n) | Inverted index or separate collection keyed by catalog number |
| Embedding model | Local `all-MiniLM-L6-v2` | Azure OpenAI `text-embedding-3-small` (better quality, managed) |
| Ingestion | Batch all-at-once | Incremental (upsert changed products only, track by modified date) |
| Metadata filtering | Single category filter | Multi-field filtered search with Qdrant's native payload filtering |
| Reranking | Post-filter boost | Cross-encoder reranker (e.g., `cross-encoder/ms-marco-MiniLM-L-6-v2`) |
| Caching | None | Redis cache for frequent queries |
| Monitoring | Print statements | Structured logging + retrieval quality metrics |

---

## 10. Key Takeaways

1. **Structured data needs flattening, not chunking** — Embedding models understand natural language, not JSON schemas
2. **ChromaDB `$contains` is not substring search** — It's a gotcha that cost debugging time; for substring matching you need application-level filtering
3. **Hybrid retrieval is essential for product catalogs** — Users ask both semantically ("cleanroom gear") and exactly ("catalog 89237-226"); pure vector search fails at exact match, pure keyword fails at semantic
4. **Dedup at extraction, not at display** — Catching duplicates early (using sets) produces cleaner documents and better embeddings
5. **Graceful degradation > hard failure** — Pipeline works without LLM (shows raw context), without metadata filters (falls back to vector-only), and without exact catalog match (falls back to semantic search)
