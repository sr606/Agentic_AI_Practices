"""
Azure OpenAI LLM integration for answer generation.
"""

from openai import AzureOpenAI

from config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_DEPLOYMENT,
    AZURE_OPENAI_ENDPOINT,
)

SYSTEM_PROMPT = """You are a helpful product search assistant for a scientific supplies catalog.
Use the provided product information to answer the user's question accurately and concisely.
If the answer is not in the provided context, say so clearly.
Include relevant catalog numbers, specifications, and sizes when applicable.
Format your response in a clear, readable way."""


def get_client() -> AzureOpenAI:
    if not AZURE_OPENAI_ENDPOINT or not AZURE_OPENAI_API_KEY:
        raise ValueError(
            "Azure OpenAI credentials not configured. Set environment variables:\n"
            "  AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com\n"
            "  AZURE_OPENAI_API_KEY=<your-key>\n"
            "  AZURE_OPENAI_DEPLOYMENT=<your-deployment-name>"
        )

    return AzureOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
    )


def generate_answer(query: str, context: str) -> str:
    """Generate a natural language answer using Azure OpenAI."""
    client = get_client()

    user_message = f"""Based on the following product information, answer the user's question.

PRODUCT INFORMATION:
{context}

USER QUESTION: {query}"""

    response = client.chat.completions.create(
        model=AZURE_OPENAI_DEPLOYMENT,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_message},
        ],
        temperature=0.3,
        max_tokens=1024,
    )

    return response.choices[0].message.content
