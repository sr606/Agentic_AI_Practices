"""
Entry point: ingest data and run interactive queries.
Usage:
    python main.py ingest          # Ingest all product JSONs into vector store
    python main.py search "query"  # Search for products
    python main.py interactive     # Interactive query loop
"""

import sys
from pathlib import Path

from config import DATA_DIR


def run_ingest(data_dir=None):
    from ingest import ingest
    ingest(data_dir=Path(data_dir) if data_dir else None)


def run_search(query: str):
    from rag_pipeline import answer_query
    print(answer_query(query))


def run_interactive():
    from rag_pipeline import answer_query

    print("RAG Product Search (type 'quit' to exit)")
    print("-" * 40)

    while True:
        try:
            query = input("\nQuery: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if query.lower() in ("quit", "exit", "q"):
            break
        if not query:
            continue

        print()
        print(answer_query(query))


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    command = sys.argv[1]

    if command == "ingest":
        data_dir = sys.argv[2] if len(sys.argv) > 2 else None
        run_ingest(data_dir)
    elif command == "search":
        if len(sys.argv) < 3:
            print("Usage: python main.py search \"your query\"")
            sys.exit(1)
        run_search(" ".join(sys.argv[2:]))
    elif command == "interactive":
        run_interactive()
    else:
        print(f"Unknown command: {command}")
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
