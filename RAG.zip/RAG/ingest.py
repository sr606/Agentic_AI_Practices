"""
Ingestion pipeline: reads product JSONs, flattens to documents, embeds, stores in ChromaDB.
"""

import chromadb
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

from config import CHROMA_PERSIST_DIR, COLLECTION_NAME, DATA_DIR, EMBEDDING_MODEL
from document_processor import process_directory


def get_collection():
    """Create or get the ChromaDB collection."""
    client = chromadb.PersistentClient(path=str(CHROMA_PERSIST_DIR))
    embedding_fn = SentenceTransformerEmbeddingFunction(model_name=EMBEDDING_MODEL)
    collection = client.get_or_create_collection(
        name=COLLECTION_NAME,
        embedding_function=embedding_fn,
        metadata={"hnsw:space": "cosine"},
    )
    return collection


def ingest(data_dir=None):
    """Run the full ingestion pipeline."""
    data_dir = data_dir or DATA_DIR
    print(f"Processing files from: {data_dir}")

    results = process_directory(data_dir)
    print(f"Processed {len(results)} products")

    if not results:
        print("No products found. Exiting.")
        return

    collection = get_collection()

    documents = []
    metadatas = []
    ids = []

    for doc_text, metadata, product_code in results:
        documents.append(doc_text)
        metadatas.append(metadata)
        ids.append(product_code)

    collection.upsert(documents=documents, metadatas=metadatas, ids=ids)
    print(f"Ingested {len(documents)} products into ChromaDB collection '{COLLECTION_NAME}'")
    print(f"Vector store persisted at: {CHROMA_PERSIST_DIR}")

    print("\n--- Sample flattened document ---")
    print(documents[0])
    print("---")


if __name__ == "__main__":
    ingest()
