"""
Flattens product JSON into natural-language documents + structured metadata.
"""

import json
from pathlib import Path


def extract_classification_features(classifications: list) -> dict:
    """Pull meaningful attributes from the nested classifications array."""
    specs = {}
    body_texts = set()
    bullet_points = set()
    sizes = set()
    colors = set()
    catalog_numbers = []

    for classification in classifications:
        for feature in classification.get("features", []):
            name = feature.get("name", "")
            values = [fv["value"] for fv in feature.get("featureValues", []) if fv.get("value")]
            if not values:
                continue
            value = values[0]

            if "BodyText" in feature.get("groupName", "") or "BodyText" in name:
                if "BulletPoint" in name or "bulletPoint" in feature.get("code", ""):
                    bullet_points.add(value)
                elif "ordering" in feature.get("code", "").lower():
                    specs["ordering_info"] = value
                else:
                    body_texts.add(value)
            elif name == "Glove Size" or "Size" in name:
                sizes.add(value)
            elif name == "Glove color" or "Color" in name.lower():
                if value != "N/A":
                    colors.add(value)
            elif name == "Cat. No.":
                catalog_numbers.append(value)
            elif feature.get("groupName") == "Specification":
                specs[name] = value
            elif name == "Material":
                specs["Material"] = value
            elif name == "Supplier Headline":
                specs["Supplier"] = value
            elif name == "Module Name":
                specs["Module Name"] = value
            elif name == "Glove Type" or "Type" in name:
                if value not in ("N/A", "EMPTY"):
                    specs.setdefault("Type", value)

    return {
        "specs": specs,
        "body_texts": list(body_texts),
        "bullet_points": list(bullet_points),
        "sizes": list(sizes),
        "colors": list(c for c in colors if c != "N/A"),
        "catalog_numbers": catalog_numbers,
    }


def flatten_product_to_document(product: dict) -> str:
    """Convert a product JSON dict into a natural-language document string."""
    lines = []

    lines.append(f"Product: {product.get('name', 'Unknown')}")

    if product.get("vendorName"):
        lines.append(f"Supplier/Vendor: {product['vendorName']}")

    categories = product.get("categories", [])
    if categories:
        cat_names = [c["name"] for c in categories if c.get("name")]
        if cat_names:
            lines.append(f"Category: {', '.join(cat_names)}")

    if product.get("summary"):
        lines.append(f"Summary: {product['summary']}")

    extracted = extract_classification_features(product.get("classifications", []))

    for text in extracted["body_texts"]:
        clean = text.replace("<br />", ". ").replace("<br/>", ". ").strip()
        lines.append(f"Description: {clean}")

    for bp in extracted["bullet_points"]:
        clean = bp.replace("<br />", ", ").replace("<br/>", ", ").strip()
        lines.append(f"Features: {clean}")

    specs = extracted["specs"]
    if specs:
        spec_parts = [f"{k}: {v}" for k, v in specs.items()
                      if k not in ("Supplier", "Module Name", "ordering_info")]
        if spec_parts:
            lines.append(f"Specifications: {' | '.join(spec_parts)}")

    if specs.get("ordering_info"):
        lines.append(f"Ordering: {specs['ordering_info']}")

    if extracted["sizes"]:
        sorted_sizes = sorted(extracted["sizes"], key=lambda x: float(x) if x.replace(".", "").isdigit() else 0)
        lines.append(f"Available Sizes: {', '.join(sorted_sizes)}")

    if extracted["colors"]:
        lines.append(f"Colors: {', '.join(set(extracted['colors']))}")

    cat_nums = extracted["catalog_numbers"] or product.get("catalogNumbers", [])
    if cat_nums:
        lines.append(f"Catalog Numbers: {', '.join(cat_nums)}")

    if product.get("vendorCatalogNumbers"):
        lines.append(f"Vendor Catalog Numbers: {', '.join(product['vendorCatalogNumbers'])}")

    return "\n".join(lines)


def extract_metadata(product: dict) -> dict:
    """Extract structured metadata for filtering."""
    extracted = extract_classification_features(product.get("classifications", []))

    categories = product.get("categories", [])
    category = categories[0]["name"] if categories else ""

    return {
        "product_code": product.get("code", ""),
        "name": product.get("name", ""),
        "vendor": product.get("vendorName", ""),
        "category": category,
        "material": extracted["specs"].get("Material", ""),
        "type": extracted["specs"].get("Type", ""),
        "disposable": extracted["specs"].get("Disposable/Reusable", ""),
        "sterile": "yes" if "sterile" in product.get("name", "").lower() else "no",
        "powder_free": "yes" if "powder-free" in product.get("name", "").lower() else "no",
        "sizes": ",".join(extracted["sizes"]) if extracted["sizes"] else "",
        "catalog_numbers": ",".join(
            extracted["catalog_numbers"] or product.get("catalogNumbers", [])
        ),
    }


def process_file(file_path: Path) -> tuple[str, dict, str]:
    """Process a single JSON file. Returns (document_text, metadata, product_code)."""
    with open(file_path) as f:
        product = json.load(f)

    doc_text = flatten_product_to_document(product)
    metadata = extract_metadata(product)
    product_code = product.get("code", file_path.stem)

    return doc_text, metadata, product_code


def process_directory(data_dir: Path) -> list[tuple[str, dict, str]]:
    """Process all JSON files in a directory."""
    results = []
    for file_path in sorted(data_dir.glob("*.json")):
        try:
            result = process_file(file_path)
            results.append(result)
        except (json.JSONDecodeError, KeyError) as e:
            print(f"Skipping {file_path.name}: {e}")
    return results
