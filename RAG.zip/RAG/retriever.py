"""
Retrieval engine: hybrid search combining vector similarity + metadata filtering.
"""

import re

import chromadb
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

from config import CHROMA_PERSIST_DIR, COLLECTION_NAME, EMBEDDING_MODEL, TOP_K


def get_collection():
    client = chromadb.PersistentClient(path=str(CHROMA_PERSIST_DIR))
    embedding_fn = SentenceTransformerEmbeddingFunction(model_name=EMBEDDING_MODEL)
    return client.get_collection(name=COLLECTION_NAME, embedding_function=embedding_fn)


def parse_query_filters(query: str) -> dict | None:
    """
    Extract metadata filters from the query for hybrid search.
    Only applies high-confidence filters that won't over-restrict results.
    """
    filters = []
    q = query.lower()

    category_keywords = {
        "glove": "Gloves",
        "bottle": "Bottles",
        "container": "Containers",
        "pipette": "Pipettes",
        "tube": "Tubes",
        "flask": "Flasks",
    }
    for keyword, cat_value in category_keywords.items():
        if keyword in q:
            filters.append({"category": cat_value})
            break

    if not filters:
        return None
    if len(filters) == 1:
        return filters[0]
    return {"$and": filters}


def post_filter_results(results: list[dict], query: str) -> list[dict]:
    """Apply soft post-retrieval filtering based on query attributes."""
    q = query.lower()

    size_match = re.search(r"size\s+(\d+\.?\d*)", q)
    target_size = size_match.group(1) if size_match else None

    if not target_size:
        return results

    boosted = []
    for r in results:
        sizes_str = r.get("metadata", {}).get("sizes", "")
        if target_size in sizes_str.split(","):
            boosted.insert(0, r)
        else:
            boosted.append(r)
    return boosted


def search(query: str, top_k: int = TOP_K, use_filters: bool = True) -> list[dict]:
    """
    Perform hybrid search: vector similarity + optional metadata filters.
    Falls back to pure vector search if filtered results are empty.
    """
    collection = get_collection()

    where_filter = parse_query_filters(query) if use_filters else None

    results = None
    if where_filter:
        try:
            results = collection.query(
                query_texts=[query],
                n_results=top_k,
                where=where_filter,
            )
        except Exception:
            pass

    if not results or not results.get("documents") or not results["documents"][0]:
        results = collection.query(
            query_texts=[query],
            n_results=top_k,
        )

    output = []
    if results and results["documents"]:
        for i, doc in enumerate(results["documents"][0]):
            output.append({
                "document": doc,
                "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                "distance": results["distances"][0][i] if results["distances"] else None,
                "id": results["ids"][0][i] if results["ids"] else None,
            })

    output = post_filter_results(output, query)
    return output


def search_by_catalog_number(catalog_number: str) -> list[dict]:
    """Direct lookup by catalog number via full collection scan."""
    collection = get_collection()
    all_results = collection.get(include=["documents", "metadatas"])

    output = []
    if all_results and all_results["documents"]:
        for i, meta in enumerate(all_results["metadatas"]):
            if catalog_number in meta.get("catalog_numbers", ""):
                output.append({
                    "document": all_results["documents"][i],
                    "metadata": meta,
                    "id": all_results["ids"][i],
                    "distance": 0.0,
                })
    return output
