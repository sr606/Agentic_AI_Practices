"""
Main RAG pipeline: query → retrieve → generate answer via Azure OpenAI.
"""

import re

from llm import generate_answer
from retriever import search, search_by_catalog_number


def format_context(results: list[dict]) -> str:
    """Format retrieved documents into a context string for the LLM."""
    if not results:
        return "No relevant products found."

    context_parts = []
    for i, result in enumerate(results, 1):
        score_info = ""
        if result.get("distance") is not None:
            similarity = 1 - result["distance"]
            score_info = f" (relevance: {similarity:.2f})"
        context_parts.append(f"[Product {i}]{score_info}\n{result['document']}")

    return "\n\n---\n\n".join(context_parts)


def query_pipeline(query: str, top_k: int = 5) -> dict:
    """
    Full RAG pipeline: query → retrieve → generate.
    """
    catalog_pattern = re.compile(r"\d{5}-\d{3}")
    catalog_match = catalog_pattern.search(query)

    if catalog_match:
        results = search_by_catalog_number(catalog_match.group())
        if not results:
            results = search(query, top_k=top_k)
    else:
        results = search(query, top_k=top_k)

    context = format_context(results)

    try:
        answer = generate_answer(query, context)
    except ValueError as e:
        answer = f"[LLM not configured] {e}\n\nRetrieved context:\n{context}"

    return {
        "query": query,
        "retrieved_products": results,
        "context": context,
        "answer": answer,
        "num_results": len(results),
    }


def answer_query(query: str, top_k: int = 5) -> str:
    """Simple interface returning the generated answer."""
    result = query_pipeline(query, top_k=top_k)

    output_lines = [
        f"Query: {result['query']}",
        f"Retrieved: {result['num_results']} products",
        "",
        "Answer:",
        result["answer"],
    ]

    return "\n".join(output_lines)
