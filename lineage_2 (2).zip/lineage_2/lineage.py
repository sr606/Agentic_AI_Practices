import os
import re
from pathlib import Path
from enum import Enum

import httpx
from dotenv import load_dotenv
from pydantic import SecretStr
from langchain_openai import AzureChatOpenAI
from graphviz import Source

load_dotenv()

# ============================================
# CONFIG
# ============================================
INPUT_DIR  = "data/input"
OUTPUT_DIR = "data/output"

SUPPORTED_EXTENSIONS = {".txt", ".pseudo", ".dsx", ".log", ".md"}

# FIX 1: Removed contradicting "First line must start with: digraph" instruction.
# The prompt requests structured sections before the digraph blocks, so the old
# system prompt actively fought the output format.
SYSTEM_PROMPT = """You are a data pipeline analyst and Graphviz DOT code generator.
When asked to produce lineage diagrams, return output in the exact structured
format requested: section headers followed by valid DOT blocks.
Do not wrap DOT code in markdown fences (no ```dot or ```).
Do not add any explanation or commentary outside the requested sections."""


# ============================================
# DIAGRAM MODE
# ============================================
class DiagramMode(str, Enum):
    TECHNICAL = "technical"
    BUSINESS  = "business"


# ============================================
# LLM SETUP
# ============================================
def get_llm() -> AzureChatOpenAI:
    endpoint   = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    api_key    = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([endpoint, deployment, api_key]):
        raise ValueError(
            "Missing Azure OpenAI env vars: "
            "AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_CHAT_DEPLOYMENT_NAME, AZURE_OPENAI_API_KEY"
        )

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=SecretStr(api_key),
        api_version="2024-02-01",
        temperature=0.0,
        streaming=False,
        http_client=httpx.Client(timeout=httpx.Timeout(300.0, read=600.0)),
    )


# ============================================
# CONSOLIDATED PROMPT
# Single-pass: extracts graph AND generates both diagrams
# ============================================
def build_extraction_prompt(pseudocode: str) -> str:
    return f"""You are a data pipeline analyst. Given a DataStage job pseudocode, produce two complete Graphviz DOT diagrams: 
Technical Lineage and Business Lineage. 
HARD CONSTRAINTS: 
1) Read all sections. Use DATA_FLOW_SUMMARY as the only source for flow structure and connectivity. 
Other sections (LINKS_SUMMARY, EXECUTION_FLOW, etc.) may be used only to identify missing nodes or attributes, but must never alter or shortcut the flow defined in DATA_FLOW_SUMMARY. 
Flow chains define true connectivity and override structure when they extend beyond it. 

2) Every non-link token in a flow chain is a node. 
Do not drop tokens due to missing description, absence from STAGES_SUMMARY, or because an upstream stage appears to be a target. 

3) Determine targets strictly from flow continuation. A node is a TARGET only if no downstream node exists in the flow chain. 
If a stage writes to a table or file explicitly present in the flow, the table/file is the TARGET, not the stage. 
Always follow the flow chain to the final materialized node. Ignore stage labels like "Target", "Output", or "Connector". 

4) If a stage has multiple output pins, each pin is a separate branch. Follow every branch independently to its own terminal. 

5) Technical diagram node labels: Line 1 = the exact token as it appears in the flow chain or pseudocode. Copy it character-for-character — no paraphrasing, no spacing changes, no substitution.
Line 2 = the DataStage stage type, resolved in this priority order: 
(a) Use the type explicitly declared in Stage_Type or STAGE_TYPES for that node. 
(b) If no declaration exists, derive a short type descriptor from the node's evident data-store category — what kind of store is it? (e.g. an Oracle table → "OracleTable", a flat file → "SeqFile", a hashed file → "HashedFile"). 
One concise noun is enough. Never write a role word (SOURCE, TARGET, TRANSFORM) as Line 2. A node present in the flow chain must appear in the diagram regardless of whether a stage type is declared — absence of a declaration invokes rule 
(b), not omission. Format: label="<exact_token>\n(<resolved_type>)" 

6) A file path or table name is only its own FILE node when it appears directly in a flow chain as a terminal with no DataStage stage of its own. 
A file path inside a stage's PROPERTIES block (e.g. file: E:\\input.csv) is metadata of that stage — not a separate node. 

7) Technical diagram node shapes by role: SOURCE → shape=folder fillcolor="#d5f5e3" style=filled LOOKUP → shape=diamond fillcolor="#fdebd0" style=filled TRANSFORM → shape=box fillcolor="#e8daef" style="rounded,filled" TARGET → shape=cylinder fillcolor="#d6eaf8" style=filled FILE → shape=note fillcolor="#fdfefe" style=filled 
Role is SOURCE if it has no upstream stage feeding into it. 
Role is TARGET only if the node has no downstream node in the flow chain. 
If a downstream table or file exists, the stage is not a target. 
Role is TRANSFORM for everything in between including pin stages, custom outputs, transaction managers, and handoff nodes. 

8) Technical diagram edges must follow flow chains. For every sequence A → B → C, create edges A → B and B → C. 
Connect every adjacent pair, including terminal tables/files. 
Apply this to every branch independently from its origin to its terminal node. 
Ensure every branch is fully connected from its origin to its terminal node, and all upstream paths to the same terminal are included. 
Use DATA_FLOW_SUMMARY as the primary source of flow. 
Complete missing connections from other sections when needed. 
Do not rely only on named links. 
Edge formatting: Use xlabel for link names (fontsize=8). 
If absent, leave unlabeled. Main path: penwidth=2 color=black. 
Others: penwidth=1 color="#555555". Reject edges: style=dashed. 
Merge multiple links between same nodes using "link1 / link2". 
Graph layout: splines=ortho with rectilinear routing.

9) Business diagram collapses the technical graph into logical groups:
   - All stages reading from the same source → one source node per
     distinct source file/table, labeled in plain English
   - All intermediate stages (transforms, pins, managers, sorters) between
     a source and a target → one transform node per path, labeled with
     what actually changes (e.g. "Rename dept_id, sort by department")
   - Each distinct output destination → one target node
   - Each distinct lookup dataset → one lookup node
   - All reject/error outputs → one "Exception output" node
   Never merge two different destinations into one node.

9b) Business diagram edge directions (strictly enforce these):
   - Source node  → Transform node  (data flows in)
   - Lookup node  → Transform node  (lookup enriches the transform, NEVER the reverse)
   - Transform node → Target node   (data flows out)
   - Exception path: Transform → Exception Handler → Exception Target
   A lookup node NEVER receives an edge from a transform in the business diagram.
   Always draw lookup → transform, not transform → lookup.

10) Business diagram node labels: plain English only. No stage IDs, no
    field names, no SQL, no file paths, no connector type names, no role words.
    Max 3 lines, max 6 words per line.
    Edge labels: plain-English verb phrase, max 4 words (e.g. "enriches
    with dept names", "routes exceptions"). Reject edges: style=dashed.

11) Both DOT blocks must be complete and syntactically valid.
    No ellipsis (...), no placeholders, no TODO inside the DOT code.
    Every node in the extracted graph must appear in both diagrams.

12) Technical diagram layout:
    rankdir=LR splines=ortho nodesep=0.5 ranksep=1.5 fontname=Helvetica
    node [fontname=Helvetica fontsize=11 width=1.8]
    edge [fontname=Helvetica fontsize=8]
    Clusters: cluster_sources / cluster_lookups / cluster_transforms / cluster_targets

13) Business diagram layout:
    rankdir=LR splines=ortho nodesep=0.5 ranksep=1.8 fontname=Helvetica
    node [fontname=Helvetica fontsize=11 width=2.0]
    edge [fontname=Helvetica fontsize=8]
    Clusters: cluster_sources / cluster_lookups / cluster_transforms / cluster_targets

OUTPUT FORMAT — return exactly this, nothing else:

### Extracted Graph
Nodes: (name · role · stage type · purpose)
Edges: (from → to · link name · type)
Main pipeline path: A → B → C → D
Side branches: (each fork point → leaf)

### Technical Lineage — Graphviz DOT
digraph TechnicalLineage {{ ... }}

### Business Lineage — Graphviz DOT
digraph BusinessLineage {{ ... }}

PSEUDOCODE INPUT:
{pseudocode}
"""


# ============================================
# BRACE-COUNTING BLOCK EXTRACTOR (fallback)
# FIX 2: Replaces the greedy regex fallback that merged both digraph
# blocks into one match when the model returned them back-to-back.
# Note: the call is currently commented out in parse_llm_response because
# the prompt now enforces section headers; keep this here as a ready fallback
# if a model response ever omits those headers again.
# ============================================
def _extract_digraph_blocks(text: str) -> list[str]:
    """
    Walks the text character-by-character, counting braces to extract
    each complete digraph {{ }} block without over-capturing.
    Returns a list of complete DOT strings in document order.
    """
    blocks = []
    search_from = 0

    while search_from < len(text):
        # Find the next digraph header
        header_match = re.search(r"digraph\s+\w+\s*\{", text[search_from:])
        if not header_match:
            break

        block_start = search_from + header_match.start()
        brace_depth = 0
        pos = block_start

        while pos < len(text):
            ch = text[pos]
            if ch == "{":
                brace_depth += 1
            elif ch == "}":
                brace_depth -= 1
                if brace_depth == 0:
                    # Found the closing brace — capture the full block
                    blocks.append(text[block_start : pos + 1])
                    search_from = pos + 1
                    break
            pos += 1
        else:
            # Unmatched opening brace — stop trying
            break

    return blocks


# ============================================
# PARSE LLM RESPONSE
# Splits the single response into two DOT blocks
# ============================================
def parse_llm_response(response: str) -> tuple[str, str]:
    """
    Extracts Technical and Business DOT blocks from the combined LLM response.
    Strategy 1 uses the section headers from the prompt's OUTPUT FORMAT.
    Strategy 2 (fallback) uses brace-counting to avoid the greedy-merge bug.
    Returns (technical_dot, business_dot). Either may be empty string on failure.
    """
    technical_dot = ""
    business_dot  = ""

    # Strategy 1: section headers (preferred — most reliable when model follows format)
    tech_pattern = re.search(
        r"###\s*Technical Lineage.*?Graphviz DOT\s*\n(digraph\s+\w+.*?)(?=###|\Z)",
        response,
        re.DOTALL | re.IGNORECASE,
    )
    biz_pattern = re.search(
        r"###\s*Business Lineage.*?Graphviz DOT\s*\n(digraph\s+\w+.*?)(?=###|\Z)",
        response,
        re.DOTALL | re.IGNORECASE,
    )

    if tech_pattern:
        technical_dot = tech_pattern.group(1).strip()
    if biz_pattern:
        business_dot = biz_pattern.group(1).strip()

    # Strategy 2: brace-counting fallback (used when section headers are missing)
    # if not technical_dot or not business_dot:
    #     print("  [Parser] Section headers not found — falling back to brace-counting extractor")
    #     all_blocks = _extract_digraph_blocks(response)
    #     if len(all_blocks) >= 1 and not technical_dot:
    #         technical_dot = all_blocks[0].strip()
    #         print(f"  [Parser] Fallback: extracted technical block ({len(technical_dot)} chars)")
    #     if len(all_blocks) >= 2 and not business_dot:
    #         business_dot = all_blocks[1].strip()
    #         print(f"  [Parser] Fallback: extracted business block ({len(business_dot)} chars)")
    #     if len(all_blocks) < 2:
    #         print(f"  [Parser] Warning: only {len(all_blocks)} digraph block(s) found in response")

    # Strip any stray markdown fences the model may have added despite instructions
    technical_dot = re.sub(r"```dot|```", "", technical_dot).strip()
    business_dot  = re.sub(r"```dot|```", "", business_dot).strip()

    return technical_dot, business_dot


# ============================================
# VALIDATE DOT
# ============================================
def validate_dot(dot_code: str, label: str) -> bool:
    """
    Runs basic structural checks on a DOT string before attempting render.
    Returns True if the block looks renderable, False otherwise.
    """
    if not dot_code:
        print(f"    [{label}] Empty DOT output")
        return False
    if not dot_code.strip().startswith("digraph"):
        print(f"    [{label}] Does not start with 'digraph'")
        return False
    if "{" not in dot_code or "}" not in dot_code:
        print(f"    [{label}] Missing braces")
        return False

    # FIX 3: Warn when business diagram labels contain file paths or field names.
    # These are constraint-10 violations — flag them so the user can inspect
    # the raw response and adjust the prompt if needed.
    if label == "BUSINESS":
        suspicious_patterns = [
            (r"[A-Za-z]:\\", "Windows file path"),
            (r"/[a-z]+/[a-z]+/", "Unix file path"),
            (r"_sk\b", "surrogate key field name"),
            (r"DSLink\d+", "internal link name"),
            (r"V\d+S\d+", "internal stage ID"),
        ]
        for pattern, description in suspicious_patterns:
            if re.search(pattern, dot_code, re.IGNORECASE):
                print(
                    f"    [{label}] ⚠️  Constraint-10 warning: label may contain {description}. "
                    f"Review raw response."
                )

    return True


# ============================================
# RENDER DOT → PNG + SVG + .dot file
# ============================================
def render_dot(dot_code: str, output_path: str, label: str) -> None:
    """
    Writes the DOT source to disk, then renders PNG and SVG via Graphviz.
    All three artefacts (dot / png / svg) are saved under output_path.
    """
    dot_file = f"{output_path}.dot"
    with open(dot_file, "w", encoding="utf-8") as f:
        f.write(dot_code)
    print(f"    [{label}] DOT  → {dot_file}")

    try:
        src = Source(dot_code)
        src.render(output_path, format="png", cleanup=False)
        print(f"    [{label}] PNG  → {output_path}.png")
        src.render(output_path, format="svg", cleanup=False)
        print(f"    [{label}] SVG  → {output_path}.svg")
    except Exception as e:
        print(f"    [{label}] Render error: {e}")
        print(f"    [{label}] DOT source preserved at {dot_file} for manual inspection")


# ============================================
# CALL LLM
# ============================================
def call_llm(prompt: str, llm: AzureChatOpenAI) -> str:
    """
    Sends system + user messages to the LLM and returns the stripped response.
    Removes any outer markdown fences the model wraps around the whole reply.
    """
    response = llm.invoke([
        ("system", SYSTEM_PROMPT),
        ("human",  prompt),
    ]).content.strip()

    # Strip outer markdown fences if model wraps the entire response
    response = re.sub(r"^```[a-z]*\n?|```$", "", response, flags=re.MULTILINE).strip()
    return response


# ============================================
# CORE FUNCTION
# ============================================
def generate_lineage_from_pseudocode(
    pseudocode: str,
    stem: str,
    llm: AzureChatOpenAI,
    output_dir: Path,
) -> None:
    """
    Takes raw pseudocode text, calls the LLM with the consolidated prompt,
    parses the response, validates both DOT blocks, and renders
    Technical + Business diagrams to PNG, SVG, and .dot files.

    Args:
        pseudocode : Raw pseudocode string (full file content)
        stem       : Base name for output files (e.g. "jbSMR3010220")
        llm        : Configured AzureChatOpenAI instance
        output_dir : Path to output directory
    """
    print(f"\n  Sending pseudocode to LLM ({len(pseudocode):,} chars)...")

    prompt   = build_extraction_prompt(pseudocode)
    response = call_llm(prompt, llm)

    # Always save raw response for debugging — useful when DOT extraction fails
    raw_path = output_dir / f"{stem}_raw_response.txt"
    raw_path.write_text(response, encoding="utf-8")
    print(f"  Raw response saved → {raw_path}")

    # Parse into two DOT blocks
    technical_dot, business_dot = parse_llm_response(response)

    # Render Technical
    if validate_dot(technical_dot, "TECHNICAL"):
        render_dot(technical_dot, str(output_dir / f"{stem}_lineage_technical"), "TECHNICAL")
    else:
        print(f"  [TECHNICAL] Skipping render — invalid DOT")
        print(f"  Preview:\n{technical_dot[:300]}")

    # Render Business
    if validate_dot(business_dot, "BUSINESS"):
        render_dot(business_dot, str(output_dir / f"{stem}_lineage_business"), "BUSINESS")
    else:
        print(f"  [BUSINESS] Skipping render — invalid DOT")
        print(f"  Preview:\n{business_dot[:300]}")


# ============================================
# FILE RUNNER
# Processes all pseudocode files in data/input
# ============================================
def run_pipeline() -> None:
    """
    Scans INPUT_DIR for supported pseudocode files, initialises one shared
    LLM client, and calls generate_lineage_from_pseudocode for each file.
    """
    input_dir  = Path(INPUT_DIR)
    output_dir = Path(OUTPUT_DIR)

    input_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    input_files = [
        f for f in input_dir.iterdir()
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if not input_files:
        print(f"[ERROR] No pseudocode files found in '{INPUT_DIR}'")
        print(f"        Supported extensions: {SUPPORTED_EXTENSIONS}")
        return

    print(f"[Found] {len(input_files)} pseudocode file(s)\n")

    llm = get_llm()

    for file in input_files:
        stem = file.stem
        print(f"{'=' * 55}")
        print(f"  File : {file.name}")
        print(f"  Stem : {stem}")
        print(f"{'=' * 55}")

        pseudocode = file.read_text(encoding="utf-8", errors="replace")

        if not pseudocode.strip():
            print(f"  [Skipped] Empty file\n")
            continue

        generate_lineage_from_pseudocode(pseudocode, stem, llm, output_dir)
        print(f"\n  [Done] {stem}\n")


# ============================================
# ENTRY
# ============================================
if __name__ == "__main__":
    run_pipeline()
