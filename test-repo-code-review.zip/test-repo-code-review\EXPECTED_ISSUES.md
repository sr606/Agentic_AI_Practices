# Expected Issues - Code Review Agent Test Cases

This document lists all intentional issues in the test repository, organized by category.

## 🔐 SECURITY VULNERABILITIES (Critical)

### SQL Injection
**Files:** `python/user_service.py`, `javascript/api-server.js`, `java/UserController.java`, `go/user_handler.go`

**Lines:**
- `user_service.py:28` - String interpolation in SQL query
- `user_service.py:35` - INSERT with string formatting
- `user_service.py:42` - UPDATE with string formatting
- `api-server.js:48` - Template literal in SQL query
- `UserController.java:39` - String concatenation in SQL
- `user_handler.go:61` - fmt.Sprintf in SQL query

**Expected Comment:**
```
SQL injection vulnerability detected. User input is directly interpolated into SQL query.
Use parameterized queries or prepared statements instead.

Example fix:
  query = "SELECT * FROM users WHERE email = ?"
  cursor.execute(query, (email,))
```

### XSS (Cross-Site Scripting)
**Files:** `javascript/api-server.js`

**Lines:**
- `api-server.js:72` - Reflecting user input without sanitization

**Expected Comment:**
```
XSS vulnerability: User input reflected in HTML without encoding.
Sanitize or encode all user input before rendering.
```

### Hardcoded Credentials
**Files:** All files

**Lines:**
- `user_service.py:16-17` - DB credentials
- `payment_processor.py:21-23` - API keys
- `api-server.js:19-24` - DB config
- `UserController.java:114-117` - Connection string
- `user_handler.go:32-37` - DB credentials
- `config/config.json` - Multiple credentials
- `config/.env` - All credentials

**Expected Comment:**
```
Hardcoded credentials detected. Move to environment variables or secure vault.
Use: os.getenv('DB_PASSWORD') or AWS Secrets Manager.
```

### Path Traversal
**Files:** `javascript/api-server.js`, `go/user_handler.go`

**Lines:**
- `api-server.js:78` - No path validation
- `user_handler.go:220` - Direct file access

**Expected Comment:**
```
Path traversal vulnerability. Validate and sanitize file paths.
Use path.join() and check if resolved path is within allowed directory.
```

### Sensitive Data Exposure
**Files:** `python/payment_processor.py`, `javascript/api-server.js`, `java/UserController.java`

**Lines:**
- `payment_processor.py:66` - Logging card numbers
- `payment_processor.py:89` - Storing CVV
- `api-server.js:155` - Logging payment details
- `UserController.java:178` - Returning password hash

**Expected Comment:**
```
Sensitive data exposure. Never log or return credit card numbers, CVVs, or passwords.
Mask sensitive data: card_number[:4] + '****' + card_number[-4:]
```

---

## ⚡ PERFORMANCE ISSUES

### N+1 Query Problem
**Files:** `python/user_service.py`, `javascript/api-server.js`, `java/UserController.java`, `go/user_handler.go`

**Lines:**
- `user_service.py:63` - Separate query per user
- `api-server.js:87` - Nested queries
- `UserController.java:91` - Loop with queries
- `user_handler.go:187` - Query in loop

**Expected Comment:**
```
N+1 query problem detected. Use JOIN or batch loading instead.

Example fix:
  query = """
    SELECT u.*, o.* FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
  """
```

### No Pagination
**Files:** `python/user_service.py`, `java/UserController.java`, `go/user_handler.go`

**Lines:**
- `user_service.py:57` - SELECT * without LIMIT
- `UserController.java:72` - No pagination
- `user_handler.go:122` - Unbounded query

**Expected Comment:**
```
Missing pagination. Large result sets can cause memory issues.
Add LIMIT/OFFSET or cursor-based pagination.
```

### Synchronous Blocking
**Files:** `python/payment_processor.py`, `javascript/api-server.js`

**Lines:**
- `payment_processor.py:42` - Blocking HTTP call
- `api-server.js:118` - Blocking computation

**Expected Comment:**
```
Synchronous blocking operation in async context.
Use async/await or move to background worker.
```

### Memory Leaks
**Files:** `javascript/api-server.js`, `java/UserController.java`

**Lines:**
- `api-server.js:109` - Event listener not removed
- `UserController.java:108` - Connection not closed

**Expected Comment:**
```
Resource leak detected. Connection/listener not closed.
Use try-with-resources or ensure cleanup in finally block.
```

---

## 🐛 CODE QUALITY ISSUES

### Missing Error Handling
**Files:** All code files

**Lines:** Too many to list (almost every function)

**Expected Comment:**
```
Missing error handling. Wrap in try-catch and handle exceptions properly.
Don't silently fail or expose internal errors to users.
```

### Missing Input Validation
**Files:** All code files

**Lines:**
- `user_service.py:33` - No email validation
- `payment_processor.py:30` - No amount validation
- `api-server.js:58` - No body validation
- `UserController.java:56` - No request validation

**Expected Comment:**
```
Missing input validation. Validate all user inputs:
- Email format
- String length limits
- Numeric ranges
- Required fields
```

### Code Duplication
**Files:** `python/user_service.py`, `java/UserController.java`

**Lines:**
- `user_service.py:48-52` vs `user_service.py:28-31`
- `UserController.java:72-86` vs `UserController.java:208-222`

**Expected Comment:**
```
Code duplication detected. Extract common logic into reusable function.
```

### Magic Numbers
**Files:** `python/user_service.py`, `javascript/api-server.js`, `java/UserController.java`

**Lines:**
- `user_service.py:68` - LIMIT 30
- `user_service.py:75` - len(password) > 5
- `api-server.js:164` - port 3000
- `UserController.java:195` - LIMIT 100

**Expected Comment:**
```
Magic number detected. Extract to named constant:
  MAX_RECENT_USERS = 30
  MIN_PASSWORD_LENGTH = 8
```

### Poor Naming
**Files:** `python/user_service.py`, `sql/schema.sql`

**Lines:**
- `user_service.py:72` - Function named 'x'
- `sql/schema.sql:60` - Table named 'prod'

**Expected Comment:**
```
Poor naming convention. Use descriptive names:
- Functions: calculate_total_price (not 'x')
- Tables: products (not 'prod')
```

---

## 🏗️ ARCHITECTURE ISSUES

### God Class/Function
**Files:** `python/user_service.py`

**Lines:**
- `user_service.py:82` - Function does too many things

**Expected Comment:**
```
Function has too many responsibilities (God function).
Split into smaller, focused functions following Single Responsibility Principle.
```

### Tight Coupling
**Files:** `python/user_service.py`, `javascript/api-server.js`

**Lines:**
- `user_service.py:21` - Direct DB connection in class
- `api-server.js:33` - Global connection

**Expected Comment:**
```
Tight coupling detected. Use dependency injection:
  def __init__(self, db_connection):
      self.conn = db_connection
```

### Missing Abstraction
**Files:** `java/UserController.java`

**Lines:**
- `UserController.java:108` - Direct JDBC usage in controller

**Expected Comment:**
```
Missing abstraction layer. Controllers should not handle database logic directly.
Create a repository/DAO layer.
```

### Global Mutable State
**Files:** `python/user_service.py`, `go/user_handler.go`

**Lines:**
- `user_service.py:96` - Global dict
- `user_handler.go:28` - Global counter

**Expected Comment:**
```
Global mutable state causes race conditions and testing issues.
Use dependency injection or thread-safe data structures.
```

---

## 🧪 TESTING ISSUES

### Missing Test Cases
**Files:** `tests/test_user_service.py`

**Lines:**
- Line 50 (commented) - No null input test
- Line 53 (commented) - No empty string test
- Line 56 (commented) - No SQL injection test

**Expected Comment:**
```
Missing critical test cases:
- Null/None inputs
- Empty strings
- SQL injection attempts
- Boundary conditions
- Error scenarios
```

### Flaky Tests
**Files:** `tests/test_user_service.py`

**Lines:**
- `test_user_service.py:42` - Time-dependent assertion

**Expected Comment:**
```
Flaky test detected. Time-based assertions can fail on slow systems.
Use mocking or remove time dependency.
```

### Test Dependencies
**Files:** `tests/test_user_service.py`

**Lines:**
- `test_user_service.py:50` - Depends on database state
- `test_user_service.py:56` - Depends on previous test

**Expected Comment:**
```
Test depends on external state or other tests.
Each test should be independent. Use setUp/tearDown for isolation.
```

### No Mocking
**Files:** `tests/test_user_service.py`

**Lines:**
- `test_user_service.py:86` - Direct database access

**Expected Comment:**
```
No mocking of external dependencies. Tests should not hit real database.
Use unittest.mock or pytest fixtures.
```

---

## 🗄️ DATABASE ISSUES

### Missing Indexes
**Files:** `sql/schema.sql`

**Lines:**
- `schema.sql:25` - No index on email
- `schema.sql:45` - No index on user_id
- `schema.sql:60` - No index on SKU

**Expected Comment:**
```
Missing index on frequently queried column.
Add: CREATE INDEX idx_users_email ON users(email);
```

### Missing Constraints
**Files:** `sql/schema.sql`

**Lines:**
- `schema.sql:23` - No unique constraint on email
- `schema.sql:45` - No foreign key
- `schema.sql:81` - No composite unique constraint

**Expected Comment:**
```
Missing database constraint. Add:
  UNIQUE KEY unique_email (email)
  FOREIGN KEY (user_id) REFERENCES users(id)
```

### Wrong Data Types
**Files:** `sql/schema.sql`

**Lines:**
- `schema.sql:18` - INT instead of BIGINT
- `schema.sql:48` - FLOAT for money
- `schema.sql:66` - FLOAT for price

**Expected Comment:**
```
Wrong data type for money. Use DECIMAL(10,2) instead of FLOAT.
FLOAT has precision issues for financial calculations.
```

### No Audit Columns
**Files:** `sql/schema.sql`

**Lines:**
- `schema.sql:20` - No updated_at
- `schema.sql:20` - No deleted_at
- `schema.sql:20` - No created_by/updated_by

**Expected Comment:**
```
Missing audit columns. Add:
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  deleted_at TIMESTAMP NULL (for soft deletes)
```

---

## 📋 CONFIGURATION ISSUES

### Credentials in Config
**Files:** `config/config.json`, `config/.env`

**Lines:** Multiple

**Expected Comment:**
```
Configuration file contains credentials. This should be in .gitignore.
Use environment variables or secret management service.
```

### Debug Mode Enabled
**Files:** `config/.env`

**Lines:**
- `.env:48` - DEBUG=true

**Expected Comment:**
```
Debug mode enabled in configuration. This should be false in production.
Debug mode can expose sensitive information.
```

### No Environment Separation
**Files:** `config/config.json`

**Lines:**
- `config.json:77` - No environment-specific config

**Expected Comment:**
```
No environment-specific configuration. Use separate configs for:
- development
- staging
- production
```

---

## 📊 SUMMARY BY FILE

### python/user_service.py
- **Security:** 5 SQL injection vulnerabilities, 1 hardcoded credential, 1 weak hashing
- **Performance:** 1 N+1 query, 1 missing pagination
- **Quality:** 10+ missing error handlers, 5 missing validations, 3 code duplications
- **Total:** 25+ issues

### python/payment_processor.py
- **Security:** 3 hardcoded API keys, 2 sensitive data exposures, 1 missing encryption
- **Performance:** 1 synchronous blocking, 1 missing retry logic
- **Quality:** 8 missing error handlers, 5 missing validations
- **Total:** 20+ issues

### javascript/api-server.js
- **Security:** 4 SQL injections, 1 XSS, 1 path traversal, 1 CORS misconfiguration
- **Performance:** 1 N+1 query, 1 memory leak, 1 blocking operation
- **Quality:** 1 callback hell, 10+ missing error handlers
- **Total:** 25+ issues

### java/UserController.java
- **Security:** 5 SQL injections, 1 hardcoded credential, 1 sensitive data exposure
- **Performance:** 1 N+1 query, 1 missing pagination, 1 resource leak
- **Quality:** 1 race condition, 3 code duplications, 8+ missing validations
- **Total:** 25+ issues

### go/user_handler.go
- **Security:** 6 SQL injections, 1 hardcoded credential, 1 path traversal
- **Performance:** 1 N+1 query, 1 missing pagination
- **Quality:** 15+ missing error handlers, 1 race condition, 1 global state
- **Total:** 30+ issues

### sql/schema.sql
- **Database:** 8 missing indexes, 6 missing constraints, 3 wrong data types
- **Security:** 2 sensitive data storage issues
- **Quality:** 4 missing audit columns, 1 circular dependency
- **Total:** 25+ issues

### tests/test_user_service.py
- **Testing:** 5 missing test cases, 1 flaky test, 2 test dependencies
- **Quality:** 1 no mocking, 2 test duplications, 1 testing implementation details
- **Total:** 15+ issues

### config/config.json + .env
- **Security:** 10+ hardcoded credentials, 1 debug mode enabled
- **Configuration:** 3 missing configurations, 1 no environment separation
- **Total:** 15+ issues

---

## 🎯 TOTAL ISSUES: 180+

### By Severity:
- **Critical (Security):** 40+
- **High (Performance):** 15+
- **Medium (Quality):** 100+
- **Low (Style):** 25+

### By Category:
- **Security Vulnerabilities:** 40+
- **Performance Issues:** 15+
- **Code Quality:** 80+
- **Architecture Issues:** 15+
- **Testing Issues:** 15+
- **Database Issues:** 25+
- **Configuration Issues:** 15+

---

## 🧪 TESTING STRATEGY

### Phase 1: File Selection
✅ Agent should select all files (no filtering)
✅ Bundle related files (e.g., user_service.py + test_user_service.py)

### Phase 2: Security Scanning
✅ Detect all SQL injection vulnerabilities
✅ Detect all hardcoded credentials
✅ Detect XSS and path traversal

### Phase 3: Performance Analysis
✅ Detect N+1 queries
✅ Detect missing pagination
✅ Detect blocking operations

### Phase 4: Code Quality
✅ Detect missing error handling
✅ Detect missing input validation
✅ Detect code duplication

### Phase 5: Cross-File Reasoning
✅ Link user_service.py with test_user_service.py
✅ Verify config files match code expectations
✅ Check SQL schema matches code queries

### Phase 6: Architecture Review
✅ Identify God classes/functions
✅ Detect tight coupling
✅ Suggest design improvements

### Phase 7: Test Coverage
✅ Identify missing test cases
✅ Detect flaky tests
✅ Suggest additional tests

---

## 📈 SUCCESS METRICS

### Minimum Acceptable Performance:
- **Recall:** Detect at least 70% of issues (126+ out of 180+)
- **Precision:** At least 80% of reported issues are valid
- **Critical Issues:** Detect 100% of SQL injection and hardcoded credentials

### Excellent Performance:
- **Recall:** Detect 90%+ of issues (162+ out of 180+)
- **Precision:** 90%+ of reported issues are valid
- **Cross-File Reasoning:** Successfully link related files
- **Architecture Insights:** Provide system-level recommendations

### Superior Performance (Better than CodeRabbit/Codeant):
- **Recall:** Detect 95%+ of issues (171+ out of 180+)
- **Precision:** 95%+ of reported issues are valid
- **Context Maintenance:** No hallucinations across large files
- **Actionable Suggestions:** Provide code examples for fixes
- **Hierarchical Analysis:** File → Module → System level insights
