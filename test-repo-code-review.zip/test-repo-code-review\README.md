# Test Repository for Code Review Agent

This repository contains intentionally flawed code samples to test code review agent capabilities.

## Structure

```
test-repo-code-review/
├── python/              # Python code samples
├── javascript/          # JavaScript/Node.js samples
├── java/                # Java samples
├── go/                  # Go samples
├── sql/                 # SQL scripts
├── config/              # Configuration files
├── docs/                # Documentation (PDF, Excel)
├── security/            # Security vulnerabilities
├── performance/         # Performance issues
└── tests/               # Test files
```

## Test Categories

### 1. Code Quality Issues
- Null pointer risks
- Missing error handling
- Code duplication
- Magic numbers
- Poor naming conventions

### 2. Security Vulnerabilities
- SQL injection
- XSS vulnerabilities
- Hardcoded credentials
- Insecure cryptography
- Path traversal

### 3. Performance Issues
- N+1 queries
- Memory leaks
- Inefficient algorithms
- Missing indexes
- Unbounded loops

### 4. Architecture Issues
- Tight coupling
- Missing abstractions
- Circular dependencies
- God objects
- Violation of SOLID principles

### 5. Test Coverage Issues
- Missing unit tests
- Missing edge cases
- Flaky tests
- Test duplication

## Usage

Use this repository to test:
1. File selection and bundling
2. Multi-language support
3. Security scanning
4. Performance analysis
5. Cross-file reasoning
6. Test coverage analysis
7. Architecture review

## Expected Review Comments

Each file has intentional issues documented in `EXPECTED_ISSUES.md`.
