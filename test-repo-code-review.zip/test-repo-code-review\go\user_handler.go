/**
 * User Handler - Go HTTP handler with multiple issues
 * 
 * ISSUES TO DETECT:
 * 1. SQL injection
 * 2. Missing error handling
 * 3. No input validation
 * 4. Resource leaks
 * 5. Race conditions
 * 6. Missing context cancellation
 * 7. Hardcoded values
 * 8. No logging
 * 9. Poor error messages
 * 10. No rate limiting
 */

package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"

	_ "github.com/go-sql-driver/mysql"
)

// ISSUE: Global mutable state (race condition)
var requestCount int

// ISSUE: Hardcoded credentials
const (
	dbUser     = "root"
	dbPassword = "admin123"
	dbHost     = "localhost"
	dbPort     = "3306"
	dbName     = "myapp"
)

// ISSUE: Global database connection (not thread-safe initialization)
var db *sql.DB

// ISSUE: No proper initialization function
func init() {
	// ISSUE: No error handling
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s", dbUser, dbPassword, dbHost, dbPort, dbName)
	db, _ = sql.Open("mysql", dsn)
	
	// ISSUE: No connection pool configuration
	// ISSUE: No ping to verify connection
}

// User struct
type User struct {
	ID    int    `json:"id"`
	Email string `json:"email"`
	Name  string `json:"name"`
}

// ISSUE: No authentication middleware
func GetUserHandler(w http.ResponseWriter, r *http.Request) {
	// ISSUE: No context usage
	// ISSUE: No request timeout
	
	// ISSUE: Poor parameter extraction
	id := r.URL.Query().Get("id")
	
	// ISSUE: No input validation
	// ISSUE: SQL injection vulnerability
	query := fmt.Sprintf("SELECT id, email, name FROM users WHERE id = %s", id)
	
	// ISSUE: No error handling
	row := db.QueryRow(query)
	
	var user User
	// ISSUE: No error handling for Scan
	row.Scan(&user.ID, &user.Email, &user.Name)
	
	// ISSUE: No error handling for JSON encoding
	json.NewEncoder(w).Encode(user)
	
	// ISSUE: No logging
	// ISSUE: No metrics
}

// ISSUE: No request body size limit
func CreateUserHandler(w http.ResponseWriter, r *http.Request) {
	// ISSUE: No content-type validation
	
	var user User
	// ISSUE: No error handling for JSON decoding
	json.NewDecoder(r.Body).Decode(&user)
	
	// ISSUE: No input validation (email format, name length, etc.)
	
	// ISSUE: SQL injection vulnerability
	query := fmt.Sprintf("INSERT INTO users (email, name) VALUES ('%s', '%s')", 
		user.Email, user.Name)
	
	// ISSUE: No error handling
	result, _ := db.Exec(query)
	
	// ISSUE: No error handling for LastInsertId
	id, _ := result.LastInsertId()
	user.ID = int(id)
	
	// ISSUE: No status code set (defaults to 200, should be 201)
	json.NewEncoder(w).Encode(user)
}

// ISSUE: No pagination
func GetAllUsersHandler(w http.ResponseWriter, r *http.Request) {
	// ISSUE: Can return millions of rows
	query := "SELECT id, email, name FROM users"
	
	// ISSUE: No error handling
	rows, _ := db.Query(query)
	// ISSUE: Resource leak (rows not closed)
	
	var users []User
	for rows.Next() {
		var user User
		// ISSUE: No error handling
		rows.Scan(&user.ID, &user.Email, &user.Name)
		users = append(users, user)
	}
	
	json.NewEncoder(w).Encode(users)
}

// ISSUE: Race condition
func IncrementCounterHandler(w http.ResponseWriter, r *http.Request) {
	// ISSUE: Not thread-safe
	requestCount++
	
	// ISSUE: No proper response format
	fmt.Fprintf(w, "%d", requestCount)
}

// ISSUE: No proper error handling
func UpdateUserHandler(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	
	var user User
	json.NewDecoder(r.Body).Decode(&user)
	
	// ISSUE: SQL injection
	query := fmt.Sprintf("UPDATE users SET email = '%s', name = '%s' WHERE id = %s",
		user.Email, user.Name, id)
	
	// ISSUE: No error handling
	db.Exec(query)
	
	// ISSUE: No verification that update succeeded
	// ISSUE: No response body
	w.WriteHeader(http.StatusOK)
}

// ISSUE: No authorization check
func DeleteUserHandler(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	
	// ISSUE: SQL injection
	query := fmt.Sprintf("DELETE FROM users WHERE id = %s", id)
	
	// ISSUE: No error handling
	db.Exec(query)
	
	// ISSUE: No confirmation of deletion
	w.WriteHeader(http.StatusNoContent)
}

// ISSUE: N+1 query problem
func GetUsersWithOrdersHandler(w http.ResponseWriter, r *http.Request) {
	// Get all users
	usersQuery := "SELECT id, email, name FROM users"
	rows, _ := db.Query(usersQuery)
	
	var results []map[string]interface{}
	
	for rows.Next() {
		var user User
		rows.Scan(&user.ID, &user.Email, &user.Name)
		
		// ISSUE: Separate query for each user
		ordersQuery := fmt.Sprintf("SELECT * FROM orders WHERE user_id = %d", user.ID)
		orderRows, _ := db.Query(ordersQuery)
		
		var orders []map[string]interface{}
		// ISSUE: Complex nested loop
		for orderRows.Next() {
			// ISSUE: Not properly handling order data
			orders = append(orders, map[string]interface{}{})
		}
		
		results = append(results, map[string]interface{}{
			"user":   user,
			"orders": orders,
		})
	}
	
	json.NewEncoder(w).Encode(results)
}

// ISSUE: Path traversal vulnerability
func GetFileHandler(w http.ResponseWriter, r *http.Request) {
	filename := r.URL.Query().Get("file")
	
	// ISSUE: No path validation
	// ISSUE: Can access any file on system
	path := fmt.Sprintf("./uploads/%s", filename)
	
	// ISSUE: No error handling
	http.ServeFile(w, r, path)
}

// ISSUE: Exposing sensitive data
func GetUserPasswordHandler(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	
	// ISSUE: Returning password hash to client
	query := fmt.Sprintf("SELECT password FROM users WHERE id = %s", id)
	
	var password string
	db.QueryRow(query).Scan(&password)
	
	// ISSUE: Exposing password
	fmt.Fprintf(w, password)
}

// ISSUE: No graceful shutdown
func main() {
	// ISSUE: No middleware (logging, recovery, CORS, etc.)
	
	http.HandleFunc("/users", GetAllUsersHandler)
	http.HandleFunc("/user", GetUserHandler)
	http.HandleFunc("/user/create", CreateUserHandler)
	http.HandleFunc("/user/update", UpdateUserHandler)
	http.HandleFunc("/user/delete", DeleteUserHandler)
	http.HandleFunc("/users/with-orders", GetUsersWithOrdersHandler)
	http.HandleFunc("/counter", IncrementCounterHandler)
	http.HandleFunc("/file", GetFileHandler)
	http.HandleFunc("/user/password", GetUserPasswordHandler)
	
	// ISSUE: Magic number (port)
	// ISSUE: No TLS configuration
	// ISSUE: No error handling
	http.ListenAndServe(":8080", nil)
	
	// ISSUE: Database connection never closed
}

// ISSUE: No health check endpoint
// ISSUE: No metrics endpoint
// ISSUE: No proper logging
// ISSUE: No configuration management
// ISSUE: No environment-specific settings
