"""
User Service - Intentionally flawed for testing code review agent

ISSUES TO DETECT:
1. SQL injection vulnerability
2. Missing input validation
3. Hardcoded credentials
4. No error handling
5. Missing null checks
6. Poor naming conventions
7. Magic numbers
8. Code duplication
9. Missing logging
10. No type hints
"""

import hashlib
import sqlite3

# ISSUE: Hardcoded credentials
DB_PASSWORD = "admin123"
DB_HOST = "localhost"


class UserService:
    def __init__(self):
        # ISSUE: No error handling for DB connection
        self.conn = sqlite3.connect("users.db")
        self.cursor = self.conn.cursor()

    # ISSUE: SQL injection vulnerability
    def get_user_by_email(self, email):
        query = f"SELECT * FROM users WHERE email = '{email}'"
        self.cursor.execute(query)
        return self.cursor.fetchone()

    # ISSUE: Missing input validation
    def create_user(self, email, password, name):
        # ISSUE: Weak password hashing (MD5)
        hashed_password = hashlib.md5(password.encode()).hexdigest()
        
        # ISSUE: SQL injection vulnerability
        query = f"INSERT INTO users (email, password, name) VALUES ('{email}', '{hashed_password}', '{name}')"
        self.cursor.execute(query)
        self.conn.commit()

    # ISSUE: Missing null check
    def update_user_email(self, user_id, new_email):
        # ISSUE: No validation of email format
        query = f"UPDATE users SET email = '{new_email}' WHERE id = {user_id}"
        self.cursor.execute(query)
        self.conn.commit()

    # ISSUE: Code duplication with get_user_by_email
    def get_user_by_id(self, user_id):
        query = f"SELECT * FROM users WHERE id = {user_id}"
        self.cursor.execute(query)
        return self.cursor.fetchone()

    # ISSUE: Missing error handling
    def delete_user(self, user_id):
        query = f"DELETE FROM users WHERE id = {user_id}"
        self.cursor.execute(query)
        self.conn.commit()

    # ISSUE: No pagination, can return millions of rows
    def get_all_users(self):
        query = "SELECT * FROM users"
        self.cursor.execute(query)
        return self.cursor.fetchall()

    # ISSUE: N+1 query problem
    def get_users_with_orders(self):
        users = self.get_all_users()
        result = []
        for user in users:
            # ISSUE: Separate query for each user
            orders_query = f"SELECT * FROM orders WHERE user_id = {user[0]}"
            self.cursor.execute(orders_query)
            orders = self.cursor.fetchall()
            result.append({"user": user, "orders": orders})
        return result

    # ISSUE: Magic number (30)
    def get_recent_users(self):
        query = "SELECT * FROM users ORDER BY created_at DESC LIMIT 30"
        self.cursor.execute(query)
        return self.cursor.fetchall()

    # ISSUE: Poor naming (what does 'x' mean?)
    def x(self, a, b):
        return a + b

    # ISSUE: Missing docstring
    def validate_password(self, password):
        # ISSUE: Weak password validation
        return len(password) > 5

    # ISSUE: No connection cleanup
    def __del__(self):
        pass  # Should close connection


# ISSUE: Global mutable state
user_cache = {}


# ISSUE: Function does too many things (God function)
def process_user_registration(email, password, name, address, phone, age, country):
    # ISSUE: No input validation
    service = UserService()
    
    # ISSUE: No error handling
    service.create_user(email, password, name)
    
    # ISSUE: Hardcoded value
    send_email(email, "Welcome!", "Thanks for registering")
    
    # ISSUE: No logging
    user_cache[email] = {"name": name, "age": age}
    
    return True


# ISSUE: Missing implementation
def send_email(to, subject, body):
    pass


# ISSUE: Unused function
def deprecated_function():
    print("This is old code")
