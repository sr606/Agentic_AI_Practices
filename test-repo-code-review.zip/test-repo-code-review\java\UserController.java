/**
 * User Controller - Spring Boot REST API with multiple issues
 * 
 * ISSUES TO DETECT:
 * 1. SQL injection via JPA native queries
 * 2. Missing input validation
 * 3. No authentication/authorization
 * 4. Resource leaks
 * 5. Null pointer risks
 * 6. Poor exception handling
 * 7. Missing logging
 * 8. Code duplication
 * 9. Magic numbers
 * 10. Thread safety issues
 */

package com.example.api.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import javax.servlet.http.HttpServletRequest;
import java.sql.*;
import java.util.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // ISSUE: Mutable shared state (thread safety issue)
    private static int requestCount = 0;

    // ISSUE: No authentication required
    @GetMapping("/{id}")
    public User getUserById(@PathVariable String id) {
        // ISSUE: SQL injection vulnerability
        String query = "SELECT * FROM users WHERE id = " + id;
        
        // ISSUE: No error handling
        List<Map<String, Object>> results = jdbcTemplate.queryForList(query);
        
        // ISSUE: No null check
        Map<String, Object> row = results.get(0);
        
        return new User(
            (Integer) row.get("id"),
            (String) row.get("email"),
            (String) row.get("name")
        );
    }

    // ISSUE: Missing input validation
    @PostMapping
    public User createUser(@RequestBody UserRequest request) {
        // ISSUE: No validation of email format
        // ISSUE: No validation of password strength
        
        // ISSUE: SQL injection vulnerability
        String query = "INSERT INTO users (email, password, name) VALUES ('" 
            + request.getEmail() + "', '" 
            + request.getPassword() + "', '" 
            + request.getName() + "')";
        
        jdbcTemplate.update(query);
        
        // ISSUE: No proper ID retrieval
        return new User(0, request.getEmail(), request.getName());
    }

    // ISSUE: No pagination (can return millions of rows)
    @GetMapping
    public List<User> getAllUsers() {
        String query = "SELECT * FROM users";
        List<Map<String, Object>> results = jdbcTemplate.queryForList(query);
        
        List<User> users = new ArrayList<>();
        for (Map<String, Object> row : results) {
            users.add(new User(
                (Integer) row.get("id"),
                (String) row.get("email"),
                (String) row.get("name")
            ));
        }
        
        return users;
    }

    // ISSUE: N+1 query problem
    @GetMapping("/with-orders")
    public List<UserWithOrders> getUsersWithOrders() {
        List<User> users = getAllUsers();
        List<UserWithOrders> result = new ArrayList<>();
        
        for (User user : users) {
            // ISSUE: Separate query for each user
            String orderQuery = "SELECT * FROM orders WHERE user_id = " + user.getId();
            List<Map<String, Object>> orders = jdbcTemplate.queryForList(orderQuery);
            result.add(new UserWithOrders(user, orders));
        }
        
        return result;
    }

    // ISSUE: Resource leak (Connection not closed)
    @GetMapping("/raw/{id}")
    public User getUserByIdRaw(@PathVariable int id) throws SQLException {
        // ISSUE: Hardcoded credentials
        Connection conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/mydb",
            "root",
            "admin123"
        );
        
        // ISSUE: SQL injection
        Statement stmt = conn.createStatement();
        String query = "SELECT * FROM users WHERE id = " + id;
        ResultSet rs = stmt.executeQuery(query);
        
        // ISSUE: No null check
        rs.next();
        
        // ISSUE: Resources not closed (memory leak)
        return new User(
            rs.getInt("id"),
            rs.getString("email"),
            rs.getString("name")
        );
    }

    // ISSUE: Poor exception handling
    @PutMapping("/{id}")
    public User updateUser(@PathVariable int id, @RequestBody UserRequest request) {
        try {
            // ISSUE: SQL injection
            String query = "UPDATE users SET email = '" + request.getEmail() 
                + "', name = '" + request.getName() 
                + "' WHERE id = " + id;
            
            jdbcTemplate.update(query);
            
            return getUserById(String.valueOf(id));
        } catch (Exception e) {
            // ISSUE: Swallowing exception
            e.printStackTrace();
            return null;
        }
    }

    // ISSUE: No authorization check
    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable int id) {
        // ISSUE: SQL injection
        String query = "DELETE FROM users WHERE id = " + id;
        jdbcTemplate.update(query);
        
        // ISSUE: No confirmation of deletion
        // ISSUE: No soft delete option
    }

    // ISSUE: Exposing sensitive data
    @GetMapping("/{id}/password")
    public String getUserPassword(@PathVariable int id) {
        String query = "SELECT password FROM users WHERE id = " + id;
        List<Map<String, Object>> results = jdbcTemplate.queryForList(query);
        
        // ISSUE: Returning password hash to client
        return (String) results.get(0).get("password");
    }

    // ISSUE: Race condition
    @PostMapping("/increment")
    public int incrementCounter() {
        // ISSUE: Not thread-safe
        requestCount++;
        return requestCount;
    }

    // ISSUE: Magic number (100)
    @GetMapping("/recent")
    public List<User> getRecentUsers() {
        String query = "SELECT * FROM users ORDER BY created_at DESC LIMIT 100";
        List<Map<String, Object>> results = jdbcTemplate.queryForList(query);
        
        List<User> users = new ArrayList<>();
        for (Map<String, Object> row : results) {
            users.add(new User(
                (Integer) row.get("id"),
                (String) row.get("email"),
                (String) row.get("name")
            ));
        }
        
        return users;
    }

    // ISSUE: Code duplication with getAllUsers
    @GetMapping("/active")
    public List<User> getActiveUsers() {
        String query = "SELECT * FROM users WHERE active = 1";
        List<Map<String, Object>> results = jdbcTemplate.queryForList(query);
        
        List<User> users = new ArrayList<>();
        for (Map<String, Object> row : results) {
            users.add(new User(
                (Integer) row.get("id"),
                (String) row.get("email"),
                (String) row.get("name")
            ));
        }
        
        return users;
    }

    // ISSUE: Missing logging
    // ISSUE: No metrics/monitoring
    // ISSUE: No API documentation
}

// ISSUE: Missing validation annotations
class UserRequest {
    private String email;
    private String password;
    private String name;
    
    // Getters and setters omitted for brevity
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getName() { return name; }
}

class User {
    private int id;
    private String email;
    private String name;
    
    public User(int id, String email, String name) {
        this.id = id;
        this.email = email;
        this.name = name;
    }
    
    public int getId() { return id; }
    public String getEmail() { return email; }
    public String getName() { return name; }
}

class UserWithOrders {
    private User user;
    private List<Map<String, Object>> orders;
    
    public UserWithOrders(User user, List<Map<String, Object>> orders) {
        this.user = user;
        this.orders = orders;
    }
}
