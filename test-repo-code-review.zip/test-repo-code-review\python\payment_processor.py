"""
Payment Processor - Security and performance issues

ISSUES TO DETECT:
1. Hardcoded API keys
2. No retry logic
3. Missing error handling
4. No logging
5. Synchronous blocking calls
6. No timeout configuration
7. Missing input validation
8. No rate limiting
9. Sensitive data in logs
10. No encryption for sensitive data
"""

import requests
import json
import time

# ISSUE: Hardcoded API credentials
STRIPE_API_KEY = "sk_live_51H7xYzKj9xYzKj9xYzKj9xYzKj9xYzKj9xYzKj9"
PAYPAL_CLIENT_ID = "AYSq3RDGsmBLJE-otTkBtM-jBEZaauaSmBLJE"
PAYPAL_SECRET = "EHnHq7dhYVmYzKj9xYzKj9xYzKj9xYzKj9xYzKj9"


class PaymentProcessor:
    def __init__(self):
        self.api_key = STRIPE_API_KEY
        # ISSUE: No validation of API key
        self.base_url = "https://api.stripe.com/v1"

    # ISSUE: No error handling
    def charge_credit_card(self, amount, card_number, cvv, expiry):
        # ISSUE: Sensitive data in plain text
        payload = {
            "amount": amount,
            "card_number": card_number,
            "cvv": cvv,
            "expiry": expiry
        }
        
        # ISSUE: No timeout, can hang forever
        response = requests.post(
            f"{self.base_url}/charges",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json=payload
        )
        
        # ISSUE: No status code check
        return response.json()

    # ISSUE: Synchronous blocking call
    def process_bulk_payments(self, payments):
        results = []
        # ISSUE: No progress tracking
        for payment in payments:
            # ISSUE: No rate limiting
            result = self.charge_credit_card(
                payment["amount"],
                payment["card_number"],
                payment["cvv"],
                payment["expiry"]
            )
            results.append(result)
            # ISSUE: Arbitrary sleep (magic number)
            time.sleep(0.1)
        return results

    # ISSUE: No input validation
    def refund_payment(self, transaction_id, amount):
        # ISSUE: No authentication check
        url = f"{self.base_url}/refunds"
        
        # ISSUE: Sensitive data in logs
        print(f"Processing refund for transaction {transaction_id}, amount: {amount}")
        
        response = requests.post(
            url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"transaction_id": transaction_id, "amount": amount}
        )
        
        return response.json()

    # ISSUE: No retry logic for failed payments
    def retry_failed_payment(self, payment_id):
        # ISSUE: Infinite retry loop
        while True:
            result = self.charge_credit_card(
                payment_id["amount"],
                payment_id["card_number"],
                payment_id["cvv"],
                payment_id["expiry"]
            )
            if result.get("status") == "success":
                break
            # ISSUE: No backoff strategy
            time.sleep(1)

    # ISSUE: Missing encryption for sensitive data
    def store_payment_info(self, user_id, card_number, cvv):
        # ISSUE: Storing CVV (PCI-DSS violation)
        payment_info = {
            "user_id": user_id,
            "card_number": card_number,
            "cvv": cvv
        }
        
        # ISSUE: Writing sensitive data to file
        with open(f"payment_{user_id}.json", "w") as f:
            json.dump(payment_info, f)

    # ISSUE: No validation of webhook signature
    def handle_webhook(self, request_data):
        # ISSUE: Trusting external data without verification
        event_type = request_data.get("type")
        
        if event_type == "payment.success":
            # ISSUE: No idempotency check
            self.process_successful_payment(request_data)
        elif event_type == "payment.failed":
            self.process_failed_payment(request_data)

    # ISSUE: Missing implementation
    def process_successful_payment(self, data):
        pass

    # ISSUE: Missing implementation
    def process_failed_payment(self, data):
        pass


# ISSUE: No connection pooling
def make_payment_request(url, data):
    # ISSUE: No error handling
    response = requests.post(url, json=data)
    return response.json()


# ISSUE: Exposing internal implementation details
class PaymentError(Exception):
    def __init__(self, message, card_number, cvv):
        self.message = message
        # ISSUE: Storing sensitive data in exception
        self.card_number = card_number
        self.cvv = cvv
        super().__init__(self.message)
