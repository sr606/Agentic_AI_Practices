/**
 * API Server - Node.js/Express with multiple issues
 * 
 * ISSUES TO DETECT:
 * 1. SQL injection
 * 2. XSS vulnerabilities
 * 3. Missing authentication
 * 4. No rate limiting
 * 5. Callback hell
 * 6. Memory leaks
 * 7. Missing error handling
 * 8. Hardcoded secrets
 * 9. No input validation
 * 10. CORS misconfiguration
 */

const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();

// ISSUE: Hardcoded credentials
const DB_CONFIG = {
    host: 'localhost',
    user: 'root',
    password: 'admin123',
    database: 'myapp'
};

// ISSUE: CORS misconfiguration (allows all origins)
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', '*');
    next();
});

app.use(bodyParser.json());

// ISSUE: No connection pooling
const connection = mysql.createConnection(DB_CONFIG);

// ISSUE: No error handling for connection
connection.connect();

// ISSUE: No authentication middleware
app.get('/api/users', (req, res) => {
    // ISSUE: SQL injection vulnerability
    const email = req.query.email;
    const query = `SELECT * FROM users WHERE email = '${email}'`;
    
    // ISSUE: No error handling
    connection.query(query, (error, results) => {
        // ISSUE: Exposing internal errors to client
        if (error) return res.status(500).json({ error: error.message });
        res.json(results);
    });
});

// ISSUE: No input validation
app.post('/api/users', (req, res) => {
    const { email, password, name } = req.body;
    
    // ISSUE: SQL injection vulnerability
    const query = `INSERT INTO users (email, password, name) VALUES ('${email}', '${password}', '${name}')`;
    
    connection.query(query, (error, results) => {
        if (error) return res.status(500).json({ error: error.message });
        res.json({ id: results.insertId });
    });
});

// ISSUE: XSS vulnerability (no output encoding)
app.get('/api/search', (req, res) => {
    const searchTerm = req.query.q;
    
    // ISSUE: Reflecting user input without sanitization
    const html = `<h1>Search results for: ${searchTerm}</h1>`;
    res.send(html);
});

// ISSUE: Path traversal vulnerability
app.get('/api/files/:filename', (req, res) => {
    const filename = req.params.filename;
    
    // ISSUE: No path validation
    const filePath = `./uploads/${filename}`;
    res.sendFile(filePath);
});

// ISSUE: Callback hell
app.post('/api/orders', (req, res) => {
    const { userId, productId, quantity } = req.body;
    
    // ISSUE: Nested callbacks (callback hell)
    connection.query(`SELECT * FROM users WHERE id = ${userId}`, (err1, user) => {
        if (err1) return res.status(500).json({ error: err1.message });
        
        connection.query(`SELECT * FROM products WHERE id = ${productId}`, (err2, product) => {
            if (err2) return res.status(500).json({ error: err2.message });
            
            connection.query(
                `INSERT INTO orders (user_id, product_id, quantity) VALUES (${userId}, ${productId}, ${quantity})`,
                (err3, result) => {
                    if (err3) return res.status(500).json({ error: err3.message });
                    
                    connection.query(
                        `UPDATE products SET stock = stock - ${quantity} WHERE id = ${productId}`,
                        (err4, updateResult) => {
                            if (err4) return res.status(500).json({ error: err4.message });
                            res.json({ orderId: result.insertId });
                        }
                    );
                }
            );
        });
    });
});

// ISSUE: Memory leak (event listeners not cleaned up)
const EventEmitter = require('events');
const emitter = new EventEmitter();

app.get('/api/subscribe', (req, res) => {
    // ISSUE: Listener added but never removed
    emitter.on('data', (data) => {
        res.write(JSON.stringify(data));
    });
    
    // ISSUE: Response never ends
});

// ISSUE: Synchronous blocking operation
app.get('/api/heavy-computation', (req, res) => {
    const n = req.query.n || 1000000;
    
    // ISSUE: Blocking the event loop
    let result = 0;
    for (let i = 0; i < n; i++) {
        result += Math.sqrt(i);
    }
    
    res.json({ result });
});

// ISSUE: No rate limiting
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    
    // ISSUE: Timing attack vulnerability
    const query = `SELECT * FROM users WHERE email = '${email}' AND password = '${password}'`;
    
    connection.query(query, (error, results) => {
        if (error) return res.status(500).json({ error: error.message });
        
        if (results.length > 0) {
            // ISSUE: No session management
            res.json({ success: true, user: results[0] });
        } else {
            res.status(401).json({ success: false });
        }
    });
});

// ISSUE: Sensitive data in logs
app.post('/api/payment', (req, res) => {
    const { cardNumber, cvv, amount } = req.body;
    
    // ISSUE: Logging sensitive data
    console.log(`Processing payment: Card ${cardNumber}, CVV ${cvv}, Amount ${amount}`);
    
    // ISSUE: No payment validation
    res.json({ success: true });
});

// ISSUE: No error handling middleware
// ISSUE: No 404 handler

// ISSUE: Magic number (port)
app.listen(3000, () => {
    console.log('Server running on port 3000');
});

// ISSUE: No graceful shutdown
// ISSUE: No process error handlers
