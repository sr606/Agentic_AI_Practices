# Testing Guide for Code Review Agent

## 🎯 Purpose

This test repository contains **180+ intentional code issues** across multiple languages and categories to comprehensively test your code review agent's capabilities.

## 📁 Repository Structure

```
test-repo-code-review/
├── README.md                    # Overview
├── EXPECTED_ISSUES.md           # Complete list of all issues (570 lines)
├── TESTING_GUIDE.md            # This file
├── .gitignore                   # Intentionally incomplete
│
├── python/                      # Python samples (45+ issues)
│   ├── user_service.py         # SQL injection, hardcoded creds, N+1 queries
│   └── payment_processor.py    # API keys, sensitive data, blocking calls
│
├── javascript/                  # JavaScript/Node.js (25+ issues)
│   └── api-server.js           # XSS, SQL injection, callback hell, memory leaks
│
├── java/                        # Java/Spring Boot (25+ issues)
│   └── UserController.java     # SQL injection, resource leaks, race conditions
│
├── go/                          # Go samples (30+ issues)
│   └── user_handler.go         # SQL injection, race conditions, no error handling
│
├── sql/                         # Database schema (25+ issues)
│   └── schema.sql              # Missing indexes, wrong data types, no constraints
│
├── config/                      # Configuration files (15+ issues)
│   ├── config.json             # Hardcoded credentials, no environment separation
│   └── .env                    # Credentials in plain text, debug mode enabled
│
└── tests/                       # Test files (15+ issues)
    └── test_user_service.py    # Flaky tests, missing cases, no mocking
```

## 🧪 Test Scenarios

### Scenario 1: Single File Review
**Command:** Review `python/user_service.py`

**Expected Results:**
- Detect 25+ issues
- SQL injection (lines 28, 35, 42, 48, 52)
- Hardcoded credentials (lines 16-17)
- N+1 query (line 63)
- Missing error handling (all functions)
- Code duplication (lines 28-31 vs 48-52)

**Success Criteria:**
- Recall: ≥70% (18+ issues detected)
- Precision: ≥80% (valid issues)
- Provide code fix examples

---

### Scenario 2: Related File Bundle
**Command:** Review `python/user_service.py` + `tests/test_user_service.py`

**Expected Results:**
- Cross-file reasoning: Link missing tests to untested code
- Identify that SQL injection in user_service.py has no security test
- Detect flaky test (line 42 in test file)
- Suggest missing test cases

**Success Criteria:**
- Detect relationship between source and test
- Suggest specific missing tests
- Identify test quality issues

---

### Scenario 3: Multi-Language Review
**Command:** Review entire repository

**Expected Results:**
- Detect issues across Python, JavaScript, Java, Go, SQL
- Identify common patterns (SQL injection in all languages)
- Detect configuration issues (hardcoded creds in all files)
- Provide language-specific fix suggestions

**Success Criteria:**
- Recall: ≥70% across all languages (126+ issues)
- No language bias (equal detection rate)
- Language-appropriate fix suggestions

---

### Scenario 4: Security-Focused Review
**Command:** Review with security focus

**Expected Results:**
- Detect all 40+ security vulnerabilities
- SQL injection (20+ instances)
- Hardcoded credentials (10+ instances)
- XSS (1 instance)
- Path traversal (2 instances)
- Sensitive data exposure (5+ instances)

**Success Criteria:**
- Recall: 100% for critical security issues
- Severity classification (Critical/High/Medium/Low)
- Remediation guidance with examples

---

### Scenario 5: Performance Review
**Command:** Review with performance focus

**Expected Results:**
- N+1 queries (5 instances)
- Missing pagination (3 instances)
- Blocking operations (2 instances)
- Memory leaks (2 instances)
- Missing indexes (8 instances)

**Success Criteria:**
- Detect all performance bottlenecks
- Explain performance impact
- Provide optimization suggestions

---

### Scenario 6: Architecture Review
**Command:** System-level architecture review

**Expected Results:**
- Identify God classes/functions
- Detect tight coupling
- Missing abstraction layers
- Global mutable state
- Violation of SOLID principles

**Success Criteria:**
- Provide system-level insights
- Suggest architectural improvements
- Explain design patterns to use

---

### Scenario 7: Database Review
**Command:** Review `sql/schema.sql`

**Expected Results:**
- Missing indexes (8 instances)
- Missing constraints (6 instances)
- Wrong data types (3 instances)
- Missing audit columns (4 instances)
- Circular dependencies (1 instance)

**Success Criteria:**
- Detect all database design issues
- Suggest proper schema design
- Explain impact of issues

---

### Scenario 8: Configuration Review
**Command:** Review `config/` directory

**Expected Results:**
- Detect hardcoded credentials in config.json
- Detect credentials in .env
- Identify that .env is not in .gitignore
- Debug mode enabled
- No environment separation

**Success Criteria:**
- Detect all configuration security issues
- Suggest proper secret management
- Recommend environment-specific configs

---

## 📊 Evaluation Metrics

### 1. Recall (Coverage)
```
Recall = (Issues Detected) / (Total Issues)

Minimum: 70% (126/180)
Good: 80% (144/180)
Excellent: 90% (162/180)
Superior: 95% (171/180)
```

### 2. Precision (Accuracy)
```
Precision = (Valid Issues) / (Total Reported)

Minimum: 80%
Good: 85%
Excellent: 90%
Superior: 95%
```

### 3. Critical Issue Detection
```
Critical Recall = (Critical Issues Detected) / (Total Critical Issues)

Target: 100% for SQL injection and hardcoded credentials
```

### 4. Cross-File Reasoning
```
- Can link source files with test files
- Can identify missing tests
- Can detect configuration mismatches
- Can provide system-level insights
```

### 5. Fix Quality
```
- Provides code examples
- Language-appropriate suggestions
- Explains why issue is problematic
- Suggests best practices
```

---

## 🎯 Comparison Benchmarks

### CodeRabbit (Baseline)
- **Recall:** ~60-70%
- **Precision:** ~75-85%
- **Cross-File:** Limited
- **Fix Quality:** Generic suggestions

### Codeant AI
- **Recall:** ~65-75%
- **Precision:** ~80-90%
- **Cross-File:** Moderate
- **Fix Quality:** Good suggestions

### Your Agent (Target)
- **Recall:** ≥90%
- **Precision:** ≥90%
- **Cross-File:** Strong (hierarchical analysis)
- **Fix Quality:** Excellent (code examples, best practices)

---

## 🚀 Testing Workflow

### Step 1: Baseline Test
```bash
# Run agent on single file
./code-review-agent review python/user_service.py

# Compare results with EXPECTED_ISSUES.md
# Calculate recall and precision
```

### Step 2: Bundle Test
```bash
# Run agent on related files
./code-review-agent review python/user_service.py tests/test_user_service.py

# Check for cross-file insights
```

### Step 3: Full Repository Test
```bash
# Run agent on entire repository
./code-review-agent review .

# Calculate overall metrics
```

### Step 4: Category-Specific Tests
```bash
# Security-focused
./code-review-agent review --focus=security .

# Performance-focused
./code-review-agent review --focus=performance .

# Architecture-focused
./code-review-agent review --focus=architecture .
```

### Step 5: Compare with Competitors
```bash
# Run CodeRabbit on same repository
# Run Codeant AI on same repository
# Compare results side-by-side
```

---

## 📈 Success Criteria Summary

### Minimum Viable Product (MVP)
- ✅ Detect 70% of issues (126/180)
- ✅ 80% precision
- ✅ 100% critical security issue detection
- ✅ Basic fix suggestions

### Production Ready
- ✅ Detect 80% of issues (144/180)
- ✅ 85% precision
- ✅ Cross-file reasoning
- ✅ Good fix suggestions with examples

### Superior to Competitors
- ✅ Detect 90% of issues (162/180)
- ✅ 90% precision
- ✅ Strong cross-file reasoning
- ✅ Hierarchical analysis (file → module → system)
- ✅ Excellent fix suggestions
- ✅ No hallucinations
- ✅ Context maintenance across large files

---

## 🔍 Detailed Testing Checklist

### Security Testing
- [ ] SQL injection detection (20+ instances)
- [ ] Hardcoded credentials (10+ instances)
- [ ] XSS detection (1 instance)
- [ ] Path traversal (2 instances)
- [ ] Sensitive data exposure (5+ instances)
- [ ] Weak cryptography (1 instance)
- [ ] Missing authentication (5+ instances)

### Performance Testing
- [ ] N+1 query detection (5 instances)
- [ ] Missing pagination (3 instances)
- [ ] Blocking operations (2 instances)
- [ ] Memory leaks (2 instances)
- [ ] Missing indexes (8 instances)

### Code Quality Testing
- [ ] Missing error handling (50+ instances)
- [ ] Missing input validation (30+ instances)
- [ ] Code duplication (10+ instances)
- [ ] Magic numbers (5+ instances)
- [ ] Poor naming (5+ instances)

### Architecture Testing
- [ ] God classes/functions (2 instances)
- [ ] Tight coupling (5+ instances)
- [ ] Missing abstractions (3 instances)
- [ ] Global mutable state (3 instances)

### Database Testing
- [ ] Missing indexes (8 instances)
- [ ] Missing constraints (6 instances)
- [ ] Wrong data types (3 instances)
- [ ] Missing audit columns (4 instances)

### Testing Quality
- [ ] Missing test cases (5+ instances)
- [ ] Flaky tests (1 instance)
- [ ] Test dependencies (2 instances)
- [ ] No mocking (3+ instances)

### Configuration Testing
- [ ] Credentials in config (10+ instances)
- [ ] Debug mode enabled (1 instance)
- [ ] Missing .gitignore entries (3+ instances)
- [ ] No environment separation (1 instance)

---

## 📝 Reporting Template

After testing, use this template to report results:

```markdown
# Code Review Agent Test Results

## Test Date: [DATE]
## Agent Version: [VERSION]

## Overall Metrics
- **Total Issues in Repository:** 180+
- **Issues Detected:** [NUMBER]
- **Recall:** [PERCENTAGE]%
- **Precision:** [PERCENTAGE]%
- **False Positives:** [NUMBER]

## By Category
| Category | Total | Detected | Recall |
|----------|-------|----------|--------|
| Security | 40+   | [N]      | [%]    |
| Performance | 15+ | [N]      | [%]    |
| Code Quality | 80+ | [N]     | [%]    |
| Architecture | 15+ | [N]     | [%]    |
| Database | 25+    | [N]      | [%]    |
| Testing | 15+     | [N]      | [%]    |
| Configuration | 15+ | [N]    | [%]    |

## Critical Issues
- **SQL Injection:** [N]/20+ detected
- **Hardcoded Credentials:** [N]/10+ detected
- **XSS:** [N]/1 detected
- **Path Traversal:** [N]/2 detected

## Cross-File Reasoning
- [ ] Linked source and test files
- [ ] Identified missing tests
- [ ] Detected config mismatches
- [ ] Provided system-level insights

## Fix Quality
- [ ] Provides code examples
- [ ] Language-appropriate
- [ ] Explains impact
- [ ] Suggests best practices

## Comparison with Competitors
| Metric | Your Agent | CodeRabbit | Codeant AI |
|--------|------------|------------|------------|
| Recall | [%]        | ~65%       | ~70%       |
| Precision | [%]     | ~80%       | ~85%       |
| Cross-File | [Rating] | Limited   | Moderate   |
| Fix Quality | [Rating] | Generic  | Good       |

## Strengths
- [List strengths]

## Weaknesses
- [List weaknesses]

## Recommendations
- [List improvements]
```

---

## 🎓 Learning Outcomes

After testing with this repository, your agent should be able to:

1. ✅ Detect security vulnerabilities across multiple languages
2. ✅ Identify performance bottlenecks
3. ✅ Recognize code quality issues
4. ✅ Provide architectural insights
5. ✅ Review database schemas
6. ✅ Assess test quality
7. ✅ Audit configuration files
8. ✅ Maintain context across large files
9. ✅ Provide actionable fix suggestions
10. ✅ Outperform existing code review tools

---

## 📞 Support

For questions or issues with this test repository:
- Review `EXPECTED_ISSUES.md` for complete issue list
- Check `README.md` for repository overview
- Compare your results with success criteria above

**Good luck testing your code review agent!** 🚀
