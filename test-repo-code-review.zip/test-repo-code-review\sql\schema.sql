-- Database Schema with multiple issues
-- 
-- ISSUES TO DETECT:
-- 1. Missing indexes on foreign keys
-- 2. No constraints on important fields
-- 3. Poor naming conventions
-- 4. Missing audit columns
-- 5. No data type optimization
-- 6. Missing unique constraints
-- 7. Circular foreign key dependencies
-- 8. No partitioning for large tables
-- 9. Missing comments/documentation
-- 10. Security issues (storing sensitive data)

-- ISSUE: No IF NOT EXISTS check
CREATE DATABASE myapp;
USE myapp;

-- ISSUE: Poor table name (plural vs singular inconsistency)
CREATE TABLE users (
    -- ISSUE: Using INT instead of BIGINT (will overflow)
    id INT PRIMARY KEY AUTO_INCREMENT,
    
    -- ISSUE: No unique constraint on email
    email VARCHAR(255),
    
    -- ISSUE: Storing password in plain text column (even if hashed, should be clear)
    password VARCHAR(255),
    
    -- ISSUE: No NOT NULL constraints
    name VARCHAR(255),
    
    -- ISSUE: Using DATETIME instead of TIMESTAMP
    created_at DATETIME,
    
    -- ISSUE: No updated_at column
    -- ISSUE: No deleted_at for soft deletes
    -- ISSUE: No created_by/updated_by audit columns
    
    -- ISSUE: VARCHAR(10) too small for phone numbers
    phone VARCHAR(10),
    
    -- ISSUE: No email validation constraint
    -- ISSUE: No index on email (frequently queried)
    
    -- ISSUE: Storing sensitive data without encryption flag
    ssn VARCHAR(11),
    credit_card VARCHAR(16)
);

-- ISSUE: Missing foreign key constraint
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    
    -- ISSUE: No foreign key to users table
    user_id INT,
    
    -- ISSUE: Using FLOAT for money (precision issues)
    total_amount FLOAT,
    
    -- ISSUE: No status column
    -- ISSUE: No order_date column
    
    -- ISSUE: No index on user_id (N+1 query risk)
    created_at DATETIME
);

-- ISSUE: Poor table name (abbreviation)
CREATE TABLE prod (
    id INT PRIMARY KEY AUTO_INCREMENT,
    
    -- ISSUE: No unique constraint on SKU
    sku VARCHAR(50),
    
    name VARCHAR(255) NOT NULL,
    
    -- ISSUE: Using FLOAT for price
    price FLOAT,
    
    -- ISSUE: No stock tracking
    -- ISSUE: No category/tags
    
    description TEXT
);

-- ISSUE: Many-to-many without junction table
-- This will cause data duplication
CREATE TABLE order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id INT,
    quantity INT,
    
    -- ISSUE: Denormalized price (should reference product)
    price FLOAT,
    
    -- ISSUE: No foreign key constraints
    -- ISSUE: No composite unique constraint on (order_id, product_id)
    
    created_at DATETIME
);

-- ISSUE: Circular dependency risk
CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255),
    
    -- ISSUE: Self-referencing without proper constraint
    manager_id INT,
    
    -- ISSUE: Foreign key to department, but department also references employee
    department_id INT,
    
    salary DECIMAL(10, 2),
    
    -- ISSUE: Storing sensitive salary data without access control
    
    FOREIGN KEY (manager_id) REFERENCES employees(id),
    FOREIGN KEY (department_id) REFERENCES departments(id)
);

CREATE TABLE departments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255),
    
    -- ISSUE: Circular reference
    head_employee_id INT,
    
    FOREIGN KEY (head_employee_id) REFERENCES employees(id)
);

-- ISSUE: Audit table without proper indexing
CREATE TABLE audit_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    
    -- ISSUE: No index on user_id (slow queries)
    user_id INT,
    
    -- ISSUE: No index on action_date (slow time-range queries)
    action_date DATETIME,
    
    action VARCHAR(50),
    
    -- ISSUE: TEXT column for details (should be JSON)
    details TEXT,
    
    -- ISSUE: No partitioning (table will grow indefinitely)
    -- ISSUE: No retention policy
    
    ip_address VARCHAR(15)  -- ISSUE: VARCHAR(15) too small for IPv6
);

-- ISSUE: Session table without cleanup mechanism
CREATE TABLE sessions (
    id VARCHAR(255) PRIMARY KEY,
    user_id INT,
    
    -- ISSUE: Storing session data in TEXT (should use Redis)
    session_data TEXT,
    
    created_at DATETIME,
    
    -- ISSUE: No expiry_at column
    -- ISSUE: No index on created_at for cleanup queries
    
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ISSUE: Missing indexes for common queries
-- CREATE INDEX idx_users_email ON users(email);
-- CREATE INDEX idx_orders_user_id ON orders(user_id);
-- CREATE INDEX idx_order_items_order_id ON order_items(order_id);
-- CREATE INDEX idx_audit_log_user_id ON audit_log(user_id);
-- CREATE INDEX idx_audit_log_action_date ON audit_log(action_date);

-- ISSUE: No views for common queries
-- ISSUE: No stored procedures for complex operations
-- ISSUE: No triggers for audit logging

-- ISSUE: Inserting test data with sensitive information
INSERT INTO users (email, password, name, ssn, credit_card) VALUES
('admin@example.com', 'admin123', 'Admin User', '123-45-6789', '4532015112830366'),
('user@example.com', 'password', 'Regular User', '987-65-4321', '5425233430109903');

-- ISSUE: No data masking for sensitive columns
-- ISSUE: No row-level security
-- ISSUE: No encryption at rest configuration
