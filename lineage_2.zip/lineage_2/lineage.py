import os
import re
from pathlib import Path
from enum import Enum

import httpx
from dotenv import load_dotenv
from pydantic import SecretStr
from langchain_openai import AzureChatOpenAI
from graphviz import Source

load_dotenv()

# ============================================
# CONFIG
# ============================================
INPUT_DIR  = "data/input"
OUTPUT_DIR = "data/output"

SUPPORTED_EXTENSIONS = {".txt", ".pseudo", ".dsx", ".log", ".md"}

SYSTEM_PROMPT = """You are a Graphviz DOT code generator.
When asked for DOT code, return only valid Graphviz DOT syntax.
No explanation. No markdown. No ```dot fences. No text outside the DOT code.
First line must start with: digraph"""


# ============================================
# DIAGRAM MODE
# ============================================
class DiagramMode(str, Enum):
    TECHNICAL = "technical"
    BUSINESS  = "business"


# ============================================
# LLM SETUP
# ============================================
def get_llm() -> AzureChatOpenAI:
    endpoint   = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    api_key    = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([endpoint, deployment, api_key]):
        raise ValueError(
            "Missing Azure OpenAI env vars: "
            "AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_CHAT_DEPLOYMENT_NAME, AZURE_OPENAI_API_KEY"
        )

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=SecretStr(api_key),
        api_version="2024-02-01",
        temperature=0.0,
        streaming=False,
        http_client=httpx.Client(timeout=httpx.Timeout(300.0, read=600.0)),
    )


# ============================================
# CONSOLIDATED PROMPT
# Single-pass: extracts graph AND generates both diagrams
# ============================================
def build_extraction_prompt(pseudocode: str) -> str:
    return f"""You are a data pipeline analyst. You will receive a DataStage job summary in pseudocode format.
Your task is to produce two Graphviz DOT diagrams from it.

---

READING STRATEGY — follow this order strictly before doing anything else:

1. SKIP to the end of the input first.
   Locate any section named: DATA_FLOW_SUMMARY, EXECUTION_FLOW,
   STAGES_SUMMARY, LINKS_SUMMARY, DATA_LINEAGE_SUMMARY,
   FLOW_STRUCTURE, or any section after "chunk pseudo code ended".
   These are your PRIMARY source of truth.

2. Extract all nodes and edges FROM THOSE SECTIONS ONLY first.
   Do not read the detailed stage blocks yet.

3. ONLY go back to detailed stage blocks if a node or edge
   referenced in the summary is missing a label, type, or purpose.
   Use the detail blocks to fill gaps — not to replace what the summary says.

4. If detail blocks contradict the summary, trust the summary.

---

STEP 1 — EXTRACT THE GRAPH

After reading the summary sections, extract silently as reasoning:

NODES: Every stage mentioned. For each note:
  - Name (use descriptive name, not internal IDs like V0S0 or V116S0P2)
  - Role: one of [SOURCE | LOOKUP | TRANSFORM | TARGET | FILE]
  - Brief label: what it does in plain English

EDGES: Every data flow between stages. For each note:
  - From → To
  - Link name if given
  - What data travels on this link (columns, filtered rows, exceptions, etc.)

---

STEP 2 — TECHNICAL LINEAGE DIAGRAM

Rules:
- Direction: left to right (rankdir=LR)
- Node shape by role:
    SOURCE    → shape=folder,       fillcolor="#d5f5e3", style=filled
    LOOKUP    → shape=diamond,      fillcolor="#fdebd0", style=filled
    TRANSFORM → shape=box,          fillcolor="#e8daef", style=filled, style="rounded,filled"
    TARGET    → shape=cylinder,     fillcolor="#d6eaf8", style=filled
    FILE      → shape=note,         fillcolor="#fdfefe", style=filled
- Node label: Stage Name + Stage Type on line 2 (e.g. OracleConnector, PxLookup, SeqFileStage)
- Edge labels: use the link name from the summary, fontsize=8
- Exception or reject edges: dashed style
- Merge duplicate edges (same source + target) into one edge, label = "link1 / link2"
- Main pipeline path (longest source-to-target chain): penwidth=2, color=black
- All other edges: penwidth=1, color="#555555"
- Group nodes in clusters:
    subgraph cluster_sources    {{ label="Sources"    ... }}
    subgraph cluster_lookups    {{ label="Lookups"    ... }}
    subgraph cluster_transforms {{ label="Transforms" ... }}
    subgraph cluster_targets    {{ label="Targets"    ... }}

Layout defaults:
    rankdir=LR, splines=ortho, nodesep=0.5, ranksep=1.5, fontname=Helvetica
    node [fontname=Helvetica fontsize=11 width=1.8]
    edge [fontname=Helvetica fontsize=8]

---

STEP 3 — BUSINESS LINEAGE DIAGRAM

Rules:
- Direction: left to right (rankdir=LR)
- Collapse technical stages into logical groups:
    All source tables/files    → one node per distinct source
    All lookups                → one node per lookup dataset
    Transformation logic       → one node summarising what changes
                                 (rename, filter, enrich, deduplicate)
    All targets                → one node per distinct target
    Exception/reject outputs   → one node labelled "Exception Output"
- Node shapes same as technical but labels are plain English only:
    No stage IDs, no SQL, no connector names, no field names
    Example: "Vehicle Off-Road Source Data" not "ORA_Ext_Vehicle_Off_Road_Data (V0S0)"
    Max 3 lines, max 6 words per line
- Edge labels: plain English verb phrase, max 4 words
    Example: "feeds", "enriches vehicle data", "routes exceptions"
- Exception or reject edges: dashed style
- Merge duplicate edges into one
- Colors:
    SOURCE    → fillcolor="#d5f5e3"
    LOOKUP    → fillcolor="#fdebd0"
    TRANSFORM → fillcolor="#e8daef"
    TARGET    → fillcolor="#d6eaf8"
    FILE      → fillcolor="#fdfefe"
- Clusters:
    subgraph cluster_sources    {{ label="Data Sources"   ... }}
    subgraph cluster_lookups    {{ label="Reference Data" ... }}
    subgraph cluster_transforms {{ label="Processing"     ... }}
    subgraph cluster_targets    {{ label="Destinations"   ... }}

Layout defaults:
    rankdir=LR, splines=ortho, nodesep=0.5, ranksep=1.8, fontname=Helvetica
    node [fontname=Helvetica fontsize=11 width=2.0]
    edge [fontname=Helvetica fontsize=8]

---

OUTPUT FORMAT — return exactly this structure, no deviation:

### Extracted Graph (brief)
Nodes: <bullet list with role>
Edges: <bullet list with link name>

### Technical Lineage — Graphviz DOT
digraph TechnicalLineage {{
  ...
}}

### Business Lineage — Graphviz DOT
digraph BusinessLineage {{
  ...
}}

---

HARD RULES
- Never use internal IDs (V0S0, V116S0P2, DSLink3) as node labels
- Never invent stages or links not present in the summary sections
- If a stage ID in the summary has no descriptive name, look it up in detail blocks only to get its name/type
- If summary contradicts detail blocks, summary wins
- Both DOT blocks must be complete and valid — no placeholders, no ellipsis inside the DOT code

---

PSEUDOCODE INPUT:
{pseudocode}
"""


# ============================================
# PARSE LLM RESPONSE
# Splits the single response into two DOT blocks
# ============================================
def parse_llm_response(response: str) -> tuple[str, str]:
    """
    Extracts Technical and Business DOT blocks from the combined LLM response.
    Returns (technical_dot, business_dot). Either may be empty string on failure.
    """
    technical_dot = ""
    business_dot  = ""

    # Strategy 1: split on the section headers
    tech_pattern = re.search(
        r"###\s*Technical Lineage.*?Graphviz DOT\s*\n(digraph\s+\w+.*?)(?=###|\Z)",
        response,
        re.DOTALL | re.IGNORECASE,
    )
    biz_pattern = re.search(
        r"###\s*Business Lineage.*?Graphviz DOT\s*\n(digraph\s+\w+.*?)(?=###|\Z)",
        response,
        re.DOTALL | re.IGNORECASE,
    )

    if tech_pattern:
        technical_dot = tech_pattern.group(1).strip()
    if biz_pattern:
        business_dot = biz_pattern.group(1).strip()

    # Strategy 2: fallback — find all digraph blocks in order
    if not technical_dot or not business_dot:
        all_blocks = re.findall(r"(digraph\s+\w+\s*\{.*?\})", response, re.DOTALL)
        if len(all_blocks) >= 1 and not technical_dot:
            technical_dot = all_blocks[0].strip()
        if len(all_blocks) >= 2 and not business_dot:
            business_dot = all_blocks[1].strip()

    # Strip stray markdown fences
    technical_dot = re.sub(r"```dot|```", "", technical_dot).strip()
    business_dot  = re.sub(r"```dot|```", "", business_dot).strip()

    return technical_dot, business_dot


# ============================================
# VALIDATE DOT
# ============================================
def validate_dot(dot_code: str, label: str) -> bool:
    if not dot_code:
        print(f"    [{label}] Empty DOT output")
        return False
    if not dot_code.strip().startswith("digraph"):
        print(f"    [{label}] Does not start with 'digraph'")
        return False
    if "{" not in dot_code or "}" not in dot_code:
        print(f"    [{label}] Missing braces")
        return False
    return True


# ============================================
# RENDER DOT → PNG + SVG + .dot file
# ============================================
def render_dot(dot_code: str, output_path: str, label: str) -> None:
    dot_file = f"{output_path}.dot"
    with open(dot_file, "w", encoding="utf-8") as f:
        f.write(dot_code)
    print(f"    [{label}] DOT  → {dot_file}")

    try:
        src = Source(dot_code)
        src.render(output_path, format="png", cleanup=False)
        print(f"    [{label}] PNG  → {output_path}.png")
        src.render(output_path, format="svg", cleanup=False)
        print(f"    [{label}] SVG  → {output_path}.svg")
    except Exception as e:
        print(f"    [{label}] Render error: {e}")


# ============================================
# CALL LLM
# ============================================
def call_llm(prompt: str, llm: AzureChatOpenAI) -> str:
    response = llm.invoke([
        ("system", SYSTEM_PROMPT),
        ("human",  prompt),
    ]).content.strip()

    # Strip outer markdown fences if model wraps entire response
    response = re.sub(r"^```[a-z]*\n?|```$", "", response, flags=re.MULTILINE).strip()
    return response


# ============================================
# CORE FUNCTION
# Drop your pseudocode here and get diagrams
# ============================================
def generate_lineage_from_pseudocode(
    pseudocode: str,
    stem: str,
    llm: AzureChatOpenAI,
    output_dir: Path,
) -> None:
    """
    Takes raw pseudocode text, calls the LLM with the consolidated prompt,
    parses the response, and renders Technical + Business diagrams.

    Args:
        pseudocode : Raw pseudocode string (full file content)
        stem       : Base name for output files (e.g. "jbSMR3010220")
        llm        : Configured AzureChatOpenAI instance
        output_dir : Path to output directory
    """
    print(f"\n  Sending pseudocode to LLM ({len(pseudocode):,} chars)...")

    prompt   = build_extraction_prompt(pseudocode)
    response = call_llm(prompt, llm)

    # Save raw LLM response for debugging
    raw_path = output_dir / f"{stem}_raw_response.txt"
    raw_path.write_text(response, encoding="utf-8")
    print(f"  Raw response saved → {raw_path}")

    # Parse into two DOT blocks
    technical_dot, business_dot = parse_llm_response(response)

    # Render Technical
    if validate_dot(technical_dot, "TECHNICAL"):
        render_dot(technical_dot, str(output_dir / f"{stem}_lineage_technical"), "TECHNICAL")
    else:
        print(f"  [TECHNICAL] Skipping render — invalid DOT")
        print(f"  Preview: {technical_dot[:300]}")

    # Render Business
    if validate_dot(business_dot, "BUSINESS"):
        render_dot(business_dot, str(output_dir / f"{stem}_lineage_business"), "BUSINESS")
    else:
        print(f"  [BUSINESS] Skipping render — invalid DOT")
        print(f"  Preview: {business_dot[:300]}")


# ============================================
# FILE RUNNER
# Processes all pseudocode files in data/input
# ============================================
def run_pipeline() -> None:
    input_dir  = Path(INPUT_DIR)
    output_dir = Path(OUTPUT_DIR)

    input_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Collect supported pseudocode files
    input_files = [
        f for f in input_dir.iterdir()
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
    ]

    if not input_files:
        print(f"[ERROR] No pseudocode files found in '{INPUT_DIR}'")
        print(f"        Supported extensions: {SUPPORTED_EXTENSIONS}")
        return

    print(f"[Found] {len(input_files)} pseudocode file(s)\n")

    llm = get_llm()

    for file in input_files:
        stem = file.stem
        print(f"{'=' * 55}")
        print(f"  File : {file.name}")
        print(f"  Stem : {stem}")
        print(f"{'=' * 55}")

        pseudocode = file.read_text(encoding="utf-8", errors="replace")

        if not pseudocode.strip():
            print(f"  [Skipped] Empty file\n")
            continue

        generate_lineage_from_pseudocode(pseudocode, stem, llm, output_dir)
        print(f"\n  [Done] {stem}\n")


# ============================================
# ENTRY
# ============================================
if __name__ == "__main__":
    run_pipeline()